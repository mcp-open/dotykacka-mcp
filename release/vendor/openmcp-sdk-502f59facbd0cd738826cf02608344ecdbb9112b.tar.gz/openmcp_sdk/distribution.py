"""Build exact client-adapter artifacts from one connector release contract.

The renderer deliberately keeps local and remote distribution mutually
exclusive.  A remote connector may produce operator metadata for OpenAI and a
Gemini CLI extension, but never an MCPB.  A local connector may produce a
Claude Desktop MCPB staging directory, but never claim hosted compatibility.

``distribution.yaml`` is separate from ``connector.yaml`` because the latter
is also consumed by the strict Go provisioner.  This keeps release tooling
from silently changing the runtime contract.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Literal, Self
from urllib.parse import urlsplit

import yaml
from pydantic import BaseModel, ConfigDict, Field as PydField
from pydantic import ValidationError, field_validator, model_validator

from openmcp_sdk.manifest import Field, Manifest, load_manifest

_CLIENT_PLATFORMS = frozenset({"darwin", "win32", "linux"})
_V1_CLAUDE_PLATFORMS = frozenset({"darwin", "win32"})
_REMOTE_ADAPTERS = frozenset({"openai", "gemini"})
_USER_CONFIG_ARG_RE = re.compile(r"^\$\{user_config\.([a-z][a-z0-9_]{0,63})\}$")
_FORBIDDEN_PARTS = frozenset(
    {
        ".git",
        ".hg",
        ".svn",
        ".venv",
        "venv",
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        "node_modules",
    }
)
_SECRET_NAME_RE = re.compile(
    r"(^|[._-])(env|secret|credentials?|private[-_]?key|id_rsa)([._-]|$)",
    re.IGNORECASE,
)
_SEMVER_RE = re.compile(
    r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
    r"(?:-(?:0|[1-9]\d*|[A-Za-z-][0-9A-Za-z-]*)"
    r"(?:\.(?:0|[1-9]\d*|[A-Za-z-][0-9A-Za-z-]*))*)?"
    r"(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$"
)
_WINDOWS_RESERVED = frozenset(
    {"con", "prn", "aux", "nul"}
    | {f"com{index}" for index in range(1, 10)}
    | {f"lpt{index}" for index in range(1, 10)}
)


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


def _validate_https_url(
    value: str, *, allow_template: bool = False, require_mcp_path: bool = False
) -> str:
    candidate = value
    if allow_template:
        candidate = re.sub(r"\{[A-Za-z][A-Za-z0-9_]*\}", "placeholder", value)
    parsed = urlsplit(candidate)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("očekává se HTTPS URL bez credentials, query a fragmentu")
    if not allow_template and ("{" in value or "}" in value):
        raise ValueError("konkrétní URL nesmí obsahovat placeholder")
    if allow_template:
        placeholders = re.findall(r"\{([^{}]+)\}", value)
        if len(placeholders) != 1 or placeholders[0] != "workspace":
            raise ValueError(
                "template URL musí obsahovat právě placeholder {workspace}"
            )
    if require_mcp_path:
        path = urlsplit(candidate).path
        if not re.fullmatch(r"/w/[^/]+/mcp", path):
            raise ValueError(
                "remote OpenMCP URL musí mít přesný tvar /w/<workspace>/mcp"
            )
    return value.rstrip("/")


def _validate_relative_path(value: str) -> str:
    path = Path(value)
    if (
        not value
        or "\\" in value
        or ":" in value
        or any(ord(char) < 32 for char in value)
        or path.is_absolute()
        or any(part in {"", ".", ".."} for part in path.parts)
        or any(
            part.endswith((" ", "."))
            or part.split(".", 1)[0].lower() in _WINDOWS_RESERVED
            for part in path.parts
        )
    ):
        raise ValueError(
            "očekává se bezpečná přenositelná relativní cesta bez '.', '..', "
            "backslash, drive prefixu a Windows reserved names"
        )
    return path.as_posix()


class Publisher(_StrictModel):
    name: str = PydField(min_length=1, max_length=128)
    homepage: str
    support: str
    documentation: str
    privacy_policy: str
    repository: str

    @field_validator(
        "homepage", "support", "documentation", "privacy_policy", "repository"
    )
    @classmethod
    def _https_urls(cls, value: str) -> str:
        return _validate_https_url(value)


class RemoteDistribution(_StrictModel):
    mcp_server_url: str
    template_mcp_server_url: str | None = None
    oauth_scopes: list[str] = PydField(default_factory=lambda: ["mcp"])
    adapters: list[Literal["openai", "gemini"]] = PydField(
        default_factory=lambda: ["openai", "gemini"]
    )
    timeout_ms: int = PydField(default=600_000, ge=1_000, le=600_000)

    @field_validator("mcp_server_url")
    @classmethod
    def _concrete_url(cls, value: str) -> str:
        return _validate_https_url(value, require_mcp_path=True)

    @field_validator("template_mcp_server_url")
    @classmethod
    def _template_url(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return _validate_https_url(
            value, allow_template=True, require_mcp_path=True
        )

    @field_validator("oauth_scopes")
    @classmethod
    def _scopes(cls, values: list[str]) -> list[str]:
        if (
            not values
            or len(values) != len(set(values))
            or any(not re.fullmatch(r"[A-Za-z0-9._:/-]{1,128}", item) for item in values)
        ):
            raise ValueError("oauth_scopes musí být neprázdné, unikátní a bezpečné")
        if values != ["mcp"]:
            raise ValueError(
                "remote OAuth v1 smí žádat pouze scope mcp; refresh token "
                "vydává OpenMCP authorization server bez OIDC offline_access"
            )
        return values

    @field_validator("adapters")
    @classmethod
    def _adapters(cls, values: list[str]) -> list[str]:
        if set(values) != _REMOTE_ADAPTERS or len(values) != 2:
            raise ValueError(
                "remote v1 musí vydat právě adaptéry openai a gemini"
            )
        return values


class LocalServer(_StrictModel):
    type: Literal["node"]
    entry_point: str
    command: Literal["node"]
    args: list[str]

    @field_validator("entry_point")
    @classmethod
    def _entry_point(cls, value: str) -> str:
        return _validate_relative_path(value)

    @field_validator("args")
    @classmethod
    def _args(cls, values: list[str]) -> list[str]:
        if not values or any("\x00" in value or "\n" in value for value in values):
            raise ValueError("server.args musí být neprázdné a bez řídicích znaků")
        return values


class ClaudeMCPB(_StrictModel):
    source_root: str = "."
    include: list[str]
    icon: str | None = None
    server: LocalServer
    platforms: list[Literal["darwin", "win32", "linux"]] = PydField(
        default_factory=lambda: ["darwin", "win32"]
    )
    claude_desktop: str | None = None
    runtime_version: str | None = PydField(default=None, min_length=1, max_length=64)

    @field_validator("source_root")
    @classmethod
    def _source_root(cls, value: str) -> str:
        if value == ".":
            return value
        return _validate_relative_path(value)

    @field_validator("include")
    @classmethod
    def _include(cls, values: list[str]) -> list[str]:
        normalized = [_validate_relative_path(value) for value in values]
        if not normalized or len(normalized) != len(set(normalized)):
            raise ValueError("include musí být neprázdný seznam unikátních cest")
        return normalized

    @field_validator("icon")
    @classmethod
    def _icon(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return _validate_relative_path(value)

    @field_validator("platforms")
    @classmethod
    def _platforms(cls, values: list[str]) -> list[str]:
        if set(values) != _V1_CLAUDE_PLATFORMS or len(values) != 2:
            raise ValueError(
                "Claude MCPB v1 musí být explicitně pro darwin i win32; "
                "linux zatím není release povrch"
            )
        return ["darwin", "win32"]

    @model_validator(mode="after")
    def _runtime(self) -> Self:
        if not self.runtime_version:
            raise ValueError("MCPB runtime vyžaduje runtime_version")

        required = {"package.json", "package-lock.json"}
        if (
            not self.server.entry_point.startswith("dist/")
            or Path(self.server.entry_point).suffix not in {".js", ".mjs", ".cjs"}
        ):
            raise ValueError(
                "node MCPB entry_point musí být build artefakt dist/*.js|mjs|cjs"
            )
        expected_entry_arg = f"${{__dirname}}/{self.server.entry_point}"

        missing = required - set(self.include)
        if missing:
            raise ValueError(
                "node MCPB musí explicitně zahrnout "
                + ", ".join(sorted(missing))
            )
        if self.icon is not None and self.icon not in self.include:
            raise ValueError("MCPB icon musí být explicitně uvedený v include")
        if self.server.command != "node" or self.server.args[0] != expected_entry_arg:
            raise ValueError(
                "node MCPB musí použít command=node "
                f"a první arg {expected_entry_arg}"
            )
        config_args = self.server.args[1:]
        matches = [_USER_CONFIG_ARG_RE.fullmatch(value) for value in config_args]
        if any(match is None for match in matches):
            raise ValueError(
                "node MCPB args po entry pointu smí obsahovat pouze "
                "${user_config.<directory_or_file>} placeholdery"
            )
        keys = [match.group(1) for match in matches if match is not None]
        if len(keys) != len(set(keys)):
            raise ValueError("node MCPB user_config args musí být unikátní")
        return self


class DistributionConfig(_StrictModel):
    schema_version: Literal[1]
    mode: Literal["remote", "local"]
    display_name: str = PydField(min_length=1, max_length=128)
    description: str = PydField(min_length=1, max_length=1_000)
    license: str = PydField(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9.+-]+$")
    publisher: Publisher
    remote: RemoteDistribution | None = None
    claude_mcpb: ClaudeMCPB | None = None

    @model_validator(mode="after")
    def _exclusive_mode(self) -> Self:
        if self.mode == "remote":
            if self.remote is None or self.claude_mcpb is not None:
                raise ValueError(
                    "remote mode vyžaduje remote blok a zakazuje claude_mcpb"
                )
        elif self.claude_mcpb is None or self.remote is not None:
            raise ValueError(
                "local mode vyžaduje claude_mcpb a zakazuje remote blok"
            )
        return self


def load_distribution(path: str | Path) -> DistributionConfig:
    source = Path(path)
    try:
        raw = yaml.safe_load(source.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise ValueError(f"distribution config {source} se nedá načíst: {exc}") from exc
    if not isinstance(raw, dict):
        raise ValueError(f"distribution config {source} musí být YAML mapa")
    try:
        return DistributionConfig.model_validate(raw)
    except ValidationError as exc:
        raise ValueError(f"neplatný distribution config {source}: {exc}") from exc


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode(
        "utf-8"
    )


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(_json_bytes(value))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _prepare_output(path: Path) -> Path:
    if path.is_symlink():
        raise ValueError(f"output nesmí být symlink: {path}")
    resolved = path.resolve()
    if resolved.exists():
        if not resolved.is_dir():
            raise ValueError(f"output {resolved} není adresář")
        if any(resolved.iterdir()):
            raise ValueError(
                f"output {resolved} není prázdný; odmítám smíchat staré artefakty"
            )
    else:
        resolved.mkdir(parents=True)
    return resolved


def _remote_tool_names(manifest: Manifest) -> list[str]:
    if manifest.display is None:
        raise ValueError("remote adapter vyžaduje display.tools")
    names = [f"{manifest.slug}__{tool.name}" for tool in manifest.display.tools]
    invalid = [
        name
        for name in names
        if len(name) > 63 or not re.fullmatch(r"[A-Za-z0-9_.-]+", name)
    ]
    if invalid:
        raise ValueError(
            "namespaced remote tool musí mít nejvýše 63 znaků a pouze "
            f"A-Z/a-z/0-9/_.-; neplatné: {', '.join(invalid)}"
        )
    if len(names) != len(set(names)):
        raise ValueError("namespaced remote tools musí být unikátní")
    return names


def _render_openai(
    manifest: Manifest, config: DistributionConfig, destination: Path
) -> Path:
    assert config.remote is not None
    tools = []
    descriptions = {
        tool.name: tool.description
        for tool in (manifest.display.tools if manifest.display else [])
    }
    for name in _remote_tool_names(manifest):
        original = name.split("__", 1)[1]
        tools.append(
            {
                "name": name,
                "description": descriptions.get(original, ""),
                "annotations": {
                    "readOnlyHint": True,
                    "destructiveHint": False,
                    "openWorldHint": True,
                },
                "securitySchemes": [
                    {"type": "oauth2", "scopes": config.remote.oauth_scopes}
                ],
            }
        )
    payload = {
        "schema": "openmcp.openai-plugin-submission.v1",
        "artifact_kind": "operator_handoff",
        "installable": False,
        "connector": {"slug": manifest.slug, "version": manifest.version},
        "name": config.display_name,
        "description": config.description,
        "mcp_server_url": config.remote.mcp_server_url,
        "template_mcp_server_url": config.remote.template_mcp_server_url,
        "authentication": {
            "type": "oauth2",
            "scopes": config.remote.oauth_scopes,
            "protected_resource_metadata": (
                config.remote.mcp_server_url.replace(
                    "/w/", "/.well-known/oauth-protected-resource/w/", 1
                )
            ),
        },
        "publisher": config.publisher.model_dump(),
        "tools": tools,
        "review_requirements": {
            "scan_tools": True,
            "concrete_review_endpoint_required": True,
            "external_demo_credentials_required": True,
            "chatgpt_web_and_mobile_e2e_required": True,
            "organization_verification_required": True,
            "domain_verification_required": True,
            "live_privacy_policy_required": True,
            "breaking_tool_schema_changes_forbidden": True,
        },
    }
    path = destination / "openai" / "submission.json"
    _write_json(path, payload)
    return path


def _deterministic_zip(source: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(item for item in source.rglob("*") if item.is_file()):
            relative = path.relative_to(source).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())


def _render_gemini(
    manifest: Manifest, config: DistributionConfig, destination: Path
) -> Path:
    assert config.remote is not None
    root = destination / "gemini"
    root.mkdir(parents=True, exist_ok=True)
    extension = {
        "name": f"openmcp-{manifest.slug}",
        "version": manifest.version,
        "description": config.description,
        "mcpServers": {
            manifest.slug: {
                "httpUrl": "${OPENMCP_MCP_URL}",
                "authProviderType": "dynamic_discovery",
                "oauth": {"scopes": config.remote.oauth_scopes},
                "timeout": config.remote.timeout_ms,
                "includeTools": _remote_tool_names(manifest),
            }
        },
        "settings": [
            {
                "name": "OpenMCP workspace URL",
                "description": (
                    "Přesná HTTPS adresa pracovního prostoru ve tvaru "
                    "https://…/w/<workspace>/mcp"
                ),
                "envVar": "OPENMCP_MCP_URL",
                "sensitive": True,
            }
        ],
        "contextFileName": "GEMINI.md",
    }
    _write_json(root / "gemini-extension.json", extension)
    (root / "GEMINI.md").write_text(
        (
            f"# {config.display_name}\n\n"
            "Používej pouze nástroje tohoto OpenMCP konektoru a respektuj jejich "
            "read-only kontrakt. Před prvním voláním dokonči OAuth přihlášení. "
            "Nikdy nežádej uživatele, aby vložil token, heslo nebo API klíč do "
            "konverzace. Pokud autentizace chybí, použij standardní `/mcp auth` flow.\n"
        ),
        encoding="utf-8",
    )
    (root / "INSTALL.md").write_text(
        (
            "# Instalace Gemini CLI Extension\n\n"
            "Tento ZIP je operátorský release candidate, ne přímý instalační "
            "formát Gemini CLI. Pro interní test jej rozbal, spusť "
            "`gemini extensions validate <složka>` a potom "
            "`gemini extensions install <složka>`. Veřejné vydání musí "
            "publikovat ověřený obsah do Git repository/tagu a používat "
            "`gemini extensions install <github-url> --ref <tag>`. Instalace "
            "si vyžádá přesnou OpenMCP workspace URL; review workspace se do "
            "extension nevkládá.\n"
        ),
        encoding="utf-8",
    )
    artifact = destination / f"openmcp-{manifest.slug}-{manifest.version}-gemini.zip"
    _deterministic_zip(root, artifact)
    return artifact


def _mcpb_user_config(field: Field) -> dict[str, Any]:
    type_map = {
        "string": "string",
        "enum": "string",
        "int": "number",
        "bool": "boolean",
        "directory": "directory",
        "file": "file",
    }
    result: dict[str, Any] = {
        "type": type_map[field.type],
        "title": field.label or field.key,
        "description": field.hint or field.label or field.key,
        "required": field.required,
    }
    if field.secret:
        result["sensitive"] = True
    if field.multiple:
        result["multiple"] = True
    if field.default is not None:
        result["default"] = field.default
    return result


def _safe_source_file(root: Path, path: Path) -> None:
    if path.is_symlink():
        raise ValueError(f"MCPB include nesmí obsahovat symlink: {path}")
    relative = path.relative_to(root)
    if any(part in _FORBIDDEN_PARTS for part in relative.parts):
        raise ValueError(f"MCPB include obsahuje vývojový adresář: {relative}")
    if _SECRET_NAME_RE.search(path.name) and path.name not in {".env.example"}:
        raise ValueError(f"MCPB include připomíná secret soubor: {relative}")
    if not path.is_file():
        raise ValueError(f"MCPB include není běžný soubor: {relative}")


def _reject_symlink_path(root: Path, candidate: Path) -> None:
    current = root
    for part in candidate.relative_to(root).parts:
        current = current / part
        if current.is_symlink():
            raise ValueError(f"MCPB include nesmí vést přes symlink: {current}")


def _copy_local_payload(source_root: Path, includes: list[str], destination: Path) -> None:
    seen: set[Path] = set()
    for include in includes:
        lexical_source = source_root / include
        _reject_symlink_path(source_root, lexical_source)
        source = lexical_source.resolve()
        try:
            source.relative_to(source_root)
        except ValueError as exc:
            raise ValueError(f"MCPB include uniká ze source_root: {include}") from exc
        if not source.exists():
            raise ValueError(f"MCPB include neexistuje: {include}")
        candidates = [source] if source.is_file() or source.is_symlink() else list(source.rglob("*"))
        for item in sorted(candidates):
            if item.is_dir():
                if item.is_symlink():
                    raise ValueError(f"MCPB include nesmí obsahovat symlink: {item}")
                continue
            _safe_source_file(source_root, item)
            relative = item.relative_to(source_root)
            if relative in seen:
                continue
            seen.add(relative)
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(item, target)
            os.chmod(target, 0o644)


def _render_mcpb(
    manifest: Manifest,
    config: DistributionConfig,
    config_path: Path,
    destination: Path,
) -> Path:
    assert config.claude_mcpb is not None
    target = destination / "claude-mcpb"
    target.mkdir(parents=True)
    config_root = config_path.parent.resolve()
    lexical_root = config_root / config.claude_mcpb.source_root
    _reject_symlink_path(config_root, lexical_root)
    source_root = lexical_root.resolve()
    if not source_root.is_dir():
        raise ValueError(f"claude_mcpb.source_root není adresář: {source_root}")
    try:
        source_root.relative_to(config_root)
    except ValueError as exc:
        raise ValueError(
            "claude_mcpb.source_root nesmí uniknout z adresáře distribution.yaml"
        ) from exc
    try:
        destination.resolve().relative_to(source_root)
    except ValueError:
        pass
    else:
        raise ValueError("output nesmí ležet uvnitř MCPB source_root")
    _copy_local_payload(source_root, config.claude_mcpb.include, target)
    entry_point = target / config.claude_mcpb.server.entry_point
    if entry_point.is_symlink() or not entry_point.is_file():
        raise ValueError(
            "claude_mcpb.server.entry_point musí být zahrnutý v MCPB payloadu"
        )

    user_config: dict[str, Any] = {}
    env: dict[str, str] = {"OPENMCP_MODE": "local-stdio"}
    for field in manifest.credentials + manifest.user_config:
        user_config[field.key] = _mcpb_user_config(field)
        if field.type not in {"directory", "file"}:
            env[manifest.env_names()[field.key]] = f"${{user_config.{field.key}}}"
    for key, env_name in manifest.runtime_secret_env_names().items():
        user_config[key] = {
            "type": "string",
            "title": key.replace("_", " ").title(),
            "description": f"Citlivá hodnota {key} pro lokální běh",
            "required": True,
            "sensitive": True,
        }
        env[env_name] = f"${{user_config.{key}}}"
    for field in manifest.operator_config:
        if field.default is not None:
            env[manifest.operator_env_names()[field.key]] = str(field.default).lower()

    runtime = config.claude_mcpb
    compatibility: dict[str, Any] = {"platforms": runtime.platforms}
    if runtime.claude_desktop:
        compatibility["claude_desktop"] = runtime.claude_desktop
    compatibility["runtimes"] = {"node": runtime.runtime_version}

    mcpb_manifest: dict[str, Any] = {
        "manifest_version": "0.4",
        "name": f"openmcp-{manifest.slug}",
        "display_name": config.display_name,
        "version": manifest.version,
        "description": config.description,
        "author": {"name": config.publisher.name, "url": config.publisher.homepage},
        "repository": {"type": "git", "url": config.publisher.repository},
        "homepage": config.publisher.homepage,
        "documentation": config.publisher.documentation,
        "support": config.publisher.support,
        "license": config.license,
        "privacy_policies": [config.publisher.privacy_policy],
        "server": {
            "type": runtime.server.type,
            "entry_point": runtime.server.entry_point,
            "mcp_config": {
                "command": runtime.server.command,
                "args": runtime.server.args,
                "env": env,
            },
        },
        "tools": [
            {"name": tool.name, "description": tool.description}
            for tool in (manifest.display.tools if manifest.display else [])
        ],
        "tools_generated": False,
        "compatibility": compatibility,
        "user_config": user_config,
    }
    if runtime.icon is not None:
        mcpb_manifest["icon"] = runtime.icon
    _write_json(target / "manifest.json", mcpb_manifest)
    (target / ".mcpbignore").write_text(
        "\n".join(
            [
                ".git/",
                ".venv/",
                "__pycache__/",
                "*.pyc",
                ".env",
                ".env.*",
                "*.pem",
                "*.key",
                "",
            ]
        ),
        encoding="utf-8",
    )
    return target


def render_distribution(
    manifest_path: str | Path, config_path: str | Path, output: str | Path
) -> dict[str, Any]:
    manifest_source = Path(manifest_path).resolve()
    config_source = Path(config_path).resolve()
    manifest = load_manifest(str(manifest_source))
    config = load_distribution(config_source)
    if (
        manifest.display is None
        or manifest.display.schema_version != 1
        or not all(locale in manifest.display.locales for locale in ("cs", "sk"))
    ):
        raise ValueError(
            "distribution vyžaduje publikační display schema_version=1 "
            "s úplnými locales.cs a locales.sk"
        )
    if manifest.capabilities.supports_write or not manifest.capabilities.default_read_only:
        raise ValueError(
            "distribuční adaptéry v1 podporují pouze manifest s pevným "
            "read-only kontraktem"
        )
    if config.mode == "local" and manifest.auth.type == "oauth_delegated":
        raise ValueError(
            "lokální MCPB v1 nepodporuje delegated OAuth; použij remote režim"
        )
    if config.mode == "local":
        assert config.claude_mcpb is not None
        path_fields = [
            field
            for field in manifest.user_config
            if field.type in {"directory", "file"}
        ]
        expected_path_args = [
            f"${{user_config.{field.key}}}" for field in path_fields
        ]
        actual_path_args = config.claude_mcpb.server.args[1:]
        if actual_path_args != expected_path_args:
            raise ValueError(
                "lokální MCPB args musí přesně a v pořadí mapovat všechna "
                "directory/file user_config pole"
            )
    if not _SEMVER_RE.fullmatch(manifest.version):
        raise ValueError(
            "distribution vyžaduje čistou SemVer verzi; PEP 440 varianty nestačí"
        )
    destination = _prepare_output(Path(output))
    artifacts: list[dict[str, str]] = []
    staging: list[str] = []
    if config.mode == "remote":
        openai = _render_openai(manifest, config, destination)
        gemini = _render_gemini(manifest, config, destination)
        for target, path in (("openai_remote", openai), ("gemini_remote", gemini)):
            artifacts.append(
                {
                    "target": target,
                    "path": path.relative_to(destination).as_posix(),
                    "sha256": _sha256(path),
                }
            )
    else:
        mcpb = _render_mcpb(manifest, config, config_source, destination)
        staging.append(mcpb.relative_to(destination).as_posix())

    result = {
        "schema": "openmcp.distribution-render.v1",
        "connector": {"slug": manifest.slug, "version": manifest.version},
        "mode": config.mode,
        "artifacts": artifacts,
        "staging": staging,
    }
    _write_json(destination / "render-result.json", result)
    return result


def pack_mcpb(
    staging: str | Path,
    output: str | Path,
    *,
    mcpb_binary: str = "mcpb",
) -> dict[str, str]:
    lexical_source = Path(staging)
    lexical_artifact = Path(output)
    if lexical_source.is_symlink() or lexical_artifact.is_symlink():
        raise ValueError("MCPB staging ani output nesmí být symlink")
    source = lexical_source.resolve()
    artifact = lexical_artifact.resolve()
    if not source.is_dir() or not (source / "manifest.json").is_file():
        raise ValueError("MCPB staging musí být adresář s manifest.json")
    if artifact.suffix != ".mcpb":
        raise ValueError("MCPB output musí mít příponu .mcpb")
    if artifact.exists():
        raise ValueError(f"MCPB output už existuje: {artifact}")
    artifact.parent.mkdir(parents=True, exist_ok=True)
    for item in source.rglob("*"):
        if item.is_symlink():
            raise ValueError(f"MCPB staging nesmí obsahovat symlink: {item}")
    with tempfile.TemporaryDirectory(prefix="openmcp-mcpb-") as temporary:
        upstream_artifact = Path(temporary) / "upstream.mcpb"
        commands = (
            [mcpb_binary, "validate", str(source / "manifest.json")],
            [mcpb_binary, "pack", str(source), str(upstream_artifact)],
        )
        for command in commands:
            try:
                completed = subprocess.run(
                    command,
                    check=False,
                    text=True,
                    capture_output=True,
                    timeout=120,
                )
            except (OSError, subprocess.TimeoutExpired) as exc:
                raise ValueError(f"mcpb nástroj se nepodařilo spustit: {exc}") from exc
            if completed.returncode != 0:
                detail = (completed.stderr or completed.stdout).strip()
                raise ValueError(f"mcpb {' '.join(command[1:2])} selhalo: {detail}")
        if not upstream_artifact.is_file() or upstream_artifact.stat().st_size == 0:
            raise ValueError("mcpb pack nevyrobil neprázdný artefakt")
        _normalize_mcpb(upstream_artifact, artifact)
    if not artifact.is_file() or artifact.stat().st_size == 0:
        raise ValueError("normalizace MCPB nevyrobila neprázdný artefakt")
    return {
        "target": "claude_mcpb",
        "path": str(artifact),
        "sha256": _sha256(artifact),
    }


def _normalize_mcpb(source: Path, output: Path) -> None:
    files: list[tuple[str, bytes]] = []
    names: set[str] = set()
    total_size = 0
    try:
        with zipfile.ZipFile(source) as archive:
            if len(archive.infolist()) > 10_000:
                raise ValueError("upstream MCPB překračuje limit 10000 entries")
            for info in archive.infolist():
                pure = PurePosixPath(info.filename)
                if (
                    not info.filename
                    or "\\" in info.filename
                    or ":" in info.filename
                    or any(ord(char) < 32 for char in info.filename)
                    or pure.is_absolute()
                    or any(part in {"", ".", ".."} for part in pure.parts)
                    or info.filename in names
                    or (
                        not info.is_dir()
                        and pure.as_posix() != info.filename
                    )
                ):
                    raise ValueError(
                        f"upstream MCPB obsahuje nebezpečnou cestu: {info.filename}"
                    )
                names.add(info.filename)
                mode = info.external_attr >> 16
                if stat.S_ISLNK(mode):
                    raise ValueError(
                        f"upstream MCPB obsahuje symlink: {info.filename}"
                    )
                if info.is_dir():
                    continue
                total_size += info.file_size
                if info.file_size > 256 * 1024 * 1024 or total_size > 512 * 1024 * 1024:
                    raise ValueError("upstream MCPB překračuje bezpečný size limit")
                files.append((pure.as_posix(), archive.read(info)))
    except (OSError, zipfile.BadZipFile) as exc:
        raise ValueError(f"upstream mcpb pack nevytvořil platný ZIP: {exc}") from exc
    if "manifest.json" not in {name for name, _ in files}:
        raise ValueError("upstream MCPB neobsahuje manifest.json")
    with zipfile.ZipFile(
        output,
        "x",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for name, content in sorted(files):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, content)
