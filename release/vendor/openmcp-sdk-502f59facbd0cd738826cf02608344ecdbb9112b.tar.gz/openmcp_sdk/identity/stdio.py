"""openmcp_sdk.identity.stdio — jednouživatelská lokální identita.

Režim local-stdio běží jako proces jednoho uživatele (Claude Desktop a
podobní MCP klienti) — headers neexistují, `sub` je vždy `"local"`.
"""

from __future__ import annotations

from typing import Mapping

from openmcp_sdk.context import Principal


class StdioIdentity:
    def principal_from_headers(self, headers: Mapping[str, str]) -> Principal:
        return Principal("local")
