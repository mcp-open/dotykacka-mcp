"""openmcp_sdk.identity — implementace IdentityProvider (stdio, gateway, oidc)."""
