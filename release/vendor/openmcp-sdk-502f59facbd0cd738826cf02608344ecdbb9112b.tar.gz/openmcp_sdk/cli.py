"""Nástroje pro příkazovou řádku dodávané se SDK."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from openmcp_sdk.distribution import pack_mcpb, render_distribution
from openmcp_sdk.manifest import Manifest, load_manifest
from openmcp_sdk.release_gate import (
    bind_trivy_report,
    build_contents_manifest,
    build_provenance_statement,
    build_withdrawal_statement,
    verify_release_gate,
)

# Zhodné s Go ``provision.slugRe``. Manifest ho už vynucuje, ale kontroluje se
# i tu s vlastní hláškou — `validate` má říct, co platforma odmítne.
_GO_SLUG_RE = re.compile(r"^[a-z][a-z0-9-]{1,30}[a-z0-9]$")


def _platform_problems(manifest: Manifest, manifest_path: Path) -> list[str]:
    """Invarianty, které vynucuje platforma (Go ``provision.ParseSpec``).

    Bez nich by `validate` řeklo OK na manifest, který API vzápětí odmítne
    — a to je horší než žádná validace, protože svádí důvěřovat.
    """
    problems: list[str] = []

    if not _GO_SLUG_RE.fullmatch(manifest.slug):
        problems.append(
            f"slug {manifest.slug!r} neprojde platformou "
            "(^[a-z][a-z0-9-]{1,30}[a-z0-9]$)"
        )
    if not manifest.name.strip():
        problems.append("name je prázdné")

    # ParseSpec: "potřebné pro NetworkPolicy"
    if manifest.egress is None:
        problems.append("chybí egress — platforma z neho generuje NetworkPolicy")
    else:
        if not manifest.egress.host:
            problems.append("chybí egress.host")
        if manifest.egress.port <= 0:
            problems.append("chybí egress.port")

    # Bez display.tools operátor neklasifikuje policies → fail-closed deny.
    if manifest.display is None or not manifest.display.tools:
        problems.append(
            "chybí display.tools — operátor by neklasifikoval žádný nástroj "
            "a konektor by se nasadil se všemi nástroji zamítnutými"
        )
    elif manifest.display.schema_version != 1 or not all(
        locale in manifest.display.locales for locale in ("cs", "sk")
    ):
        problems.append(
            "display musí mít schema_version: 1 a úplné locales.cs/locales.sk"
        )

    problems.extend(_dockerfile_problems(manifest, manifest_path))
    return problems


def _dockerfile_problems(manifest: Manifest, manifest_path: Path) -> list[str]:
    """Adresář v Dockerfile musí odpovídat slugu.

    Build kontext (``deploy/Makefile``) přejmenovává adresář repozitáře na slug,
    takže ``COPY <něco>`` s jiným jménem se nezkompiluje. Právě na tomto padal
    každý konektor scaffoldnutý ze šablony: zdědil ``COPY template ./template``.
    """
    dockerfile = manifest_path.parent / "Dockerfile"
    if not dockerfile.is_file():
        return []
    text = dockerfile.read_text(encoding="utf-8")
    # Tolerantnější než přesná shoda obou stran: `COPY --chown=… src ./src`
    # i `COPY src/ ./src/` jsou běžné tvary. Předchozí regex jejich buď
    # neviděl (a přehlédl právě ten bug, kvůli kterému check existuje), nebo
    # na nich hlásil falešný poplach.
    copied: set[str] = set()
    for line in text.splitlines():
        match = re.match(r"\s*COPY\s+(?P<rest>.+)$", line)
        if not match:
            continue
        parts = [p for p in match.group("rest").split() if not p.startswith("--")]
        if len(parts) != 2:
            continue
        src, dst = (p.strip("/") for p in parts)
        src = src.removeprefix("./")
        dst = dst.removeprefix("./")
        if src and src == dst:
            copied.add(src)
    # `sdk` je vždy přítomné (SDK je lokální závislost), konektor je ten druhý.
    connector_dirs = copied - {"sdk"}
    if connector_dirs and manifest.slug not in connector_dirs:
        return [
            f"Dockerfile kopíruje {sorted(connector_dirs)}, ale slug je "
            f"{manifest.slug!r} — build kontext přejmenovává adresář na slug, "
            "takže build selže"
        ]
    return []


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="openmcp-sdk")
    subparsers = parser.add_subparsers(dest="command", required=True)
    validate = subparsers.add_parser("validate", help="ověří connector.yaml")
    validate.add_argument("manifest", help="cesta k connector.yaml")
    validate.add_argument(
        "--sdk-only",
        action="store_true",
        help="přeskoč invarianty platformy (jen schéma SDK)",
    )
    render = subparsers.add_parser(
        "render-adapters",
        help="vyrenderuje exact-client distribuční adaptéry",
    )
    render.add_argument("manifest", help="cesta k connector.yaml")
    render.add_argument("distribution", help="cesta k distribution.yaml")
    render.add_argument("--output", required=True, help="prázdný output adresář")

    pack = subparsers.add_parser(
        "pack-mcpb",
        help="ověří a zabalí připravený Claude MCPB adresář",
    )
    pack.add_argument("staging", help="adresář s MCPB manifest.json")
    pack.add_argument("--output", required=True, help="výstupní .mcpb soubor")
    pack.add_argument(
        "--mcpb-bin",
        default="mcpb",
        help="cesta k připnutému mcpb CLI (výchozí: mcpb)",
    )

    contents = subparsers.add_parser(
        "build-contents-manifest",
        help="sváže přesný artifact payload a build inputs",
    )
    contents.add_argument("--artifact", required=True)
    contents.add_argument("--artifact-name", required=True)
    contents.add_argument(
        "--build-input",
        action="append",
        default=[],
        metavar="NAME=PATH",
    )
    contents.add_argument("--output", required=True)

    bind_scan = subparsers.add_parser(
        "bind-trivy-report",
        help="sváže content scan s přesným artifact manifestem",
    )
    bind_scan.add_argument("--report", required=True)
    bind_scan.add_argument("--artifact-name", required=True)
    bind_scan.add_argument("--contents-manifest", required=True)
    bind_scan.add_argument(
        "--required-target",
        action="append",
        default=[],
    )
    bind_scan.add_argument("--output", required=True)

    provenance = subparsers.add_parser(
        "build-provenance",
        help="vytvoří SLSA/in-toto statement před keyless podpisem",
    )
    provenance.add_argument("--artifact", required=True)
    provenance.add_argument("--artifact-name", required=True)
    provenance.add_argument("--source-repository", required=True)
    provenance.add_argument("--source-commit", required=True)
    provenance.add_argument("--builder-identity", required=True)
    provenance.add_argument("--invocation-id", required=True)
    provenance.add_argument("--target", required=True)
    provenance.add_argument(
        "--lock",
        action="append",
        default=[],
        metavar="NAME=PATH",
        help="lockfile a jeho release-relative jméno; lze opakovat",
    )
    provenance.add_argument("--output", required=True)

    gate = subparsers.add_parser(
        "verify-release",
        help="fail-closed ověří SBOM, scan, podpis a provenance",
    )
    gate.add_argument("gate", help="cesta k release-gate.yaml")
    gate.add_argument("--root", default=".", help="root všech evidence cest")
    gate.add_argument("--source-commit", required=True)
    gate.add_argument("--output", required=True)
    gate.add_argument(
        "--cosign-bin",
        default="cosign",
        help="cesta k připnutému cosign CLI (výchozí: cosign)",
    )

    withdrawal = subparsers.add_parser(
        "withdraw-release",
        help="vytvoří withdrawal statement navázaný na přesný release evidence",
    )
    withdrawal.add_argument("--evidence", required=True)
    withdrawal.add_argument("--evidence-bundle", required=True)
    withdrawal.add_argument("--release-reference", required=True)
    withdrawal.add_argument("--reason", required=True)
    withdrawal.add_argument("--actor", required=True)
    withdrawal.add_argument("--certificate-identity", required=True)
    withdrawal.add_argument(
        "--oidc-issuer",
        default="https://token.actions.githubusercontent.com",
    )
    withdrawal.add_argument("--cosign-bin", default="cosign")
    withdrawal.add_argument("--incident-url")
    withdrawal.add_argument("--output", required=True)
    args = parser.parse_args(argv)

    if args.command == "render-adapters":
        try:
            result = render_distribution(args.manifest, args.distribution, args.output)
        except (OSError, ValueError) as exc:
            print(f"adapter render failed: {exc}", file=sys.stderr)
            return 2
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0

    if args.command == "pack-mcpb":
        try:
            result = pack_mcpb(args.staging, args.output, mcpb_binary=args.mcpb_bin)
        except (OSError, ValueError) as exc:
            print(f"MCPB pack failed: {exc}", file=sys.stderr)
            return 2
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0

    if args.command == "build-contents-manifest":
        inputs: list[tuple[str, str]] = []
        for value in args.build_input:
            if "=" not in value:
                print(
                    "content manifest failed: --build-input musí být NAME=PATH",
                    file=sys.stderr,
                )
                return 2
            name, path = value.split("=", 1)
            inputs.append((name, path))
        try:
            result = build_contents_manifest(
                artifact=args.artifact,
                artifact_name=args.artifact_name,
                build_inputs=inputs,
            )
            output = Path(args.output)
            if output.exists():
                raise ValueError(f"output už existuje: {output}")
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(
                json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
        except (OSError, ValueError) as exc:
            print(f"content manifest failed: {exc}", file=sys.stderr)
            return 2
        print(f"content manifest: {output}")
        return 0

    if args.command == "bind-trivy-report":
        try:
            result = bind_trivy_report(
                report=args.report,
                artifact_name=args.artifact_name,
                contents_manifest=args.contents_manifest,
                required_targets=args.required_target,
            )
            output = Path(args.output)
            if output.exists():
                raise ValueError(f"output už existuje: {output}")
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(
                json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
        except (OSError, ValueError) as exc:
            print(f"Trivy binding failed: {exc}", file=sys.stderr)
            return 2
        print(f"Trivy report: {output}")
        return 0

    if args.command == "build-provenance":
        locks: list[tuple[str, str]] = []
        for value in args.lock:
            if "=" not in value:
                print("provenance failed: --lock musí být NAME=PATH", file=sys.stderr)
                return 2
            name, path = value.split("=", 1)
            locks.append((name, path))
        try:
            statement = build_provenance_statement(
                artifact=args.artifact,
                artifact_name=args.artifact_name,
                source_repository=args.source_repository,
                source_commit=args.source_commit,
                builder_identity=args.builder_identity,
                invocation_id=args.invocation_id,
                target=args.target,
                lockfiles=locks,
            )
            output = Path(args.output)
            if output.exists():
                raise ValueError(f"output už existuje: {output}")
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(
                json.dumps(statement, ensure_ascii=False, indent=2, sort_keys=True)
                + "\n",
                encoding="utf-8",
            )
        except (OSError, ValueError) as exc:
            print(f"provenance failed: {exc}", file=sys.stderr)
            return 2
        print(f"provenance: {output}")
        return 0

    if args.command == "verify-release":
        try:
            result = verify_release_gate(
                args.gate,
                root=args.root,
                source_commit=args.source_commit,
                output=args.output,
                cosign_binary=args.cosign_bin,
            )
        except (OSError, ValueError) as exc:
            print(f"release ineligible: {exc}", file=sys.stderr)
            return 2
        print(
            f"release eligible: {len(result['artifacts'])} artifact(s) "
            f"at {result['source']['commit']}"
        )
        return 0

    if args.command == "withdraw-release":
        try:
            statement = build_withdrawal_statement(
                release_evidence=args.evidence,
                evidence_bundle=args.evidence_bundle,
                release_reference=args.release_reference,
                reason=args.reason,
                actor=args.actor,
                certificate_identity=args.certificate_identity,
                oidc_issuer=args.oidc_issuer,
                cosign_binary=args.cosign_bin,
                incident_url=args.incident_url,
            )
            output = Path(args.output)
            if output.exists():
                raise ValueError(f"output už existuje: {output}")
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(
                json.dumps(statement, ensure_ascii=False, indent=2, sort_keys=True)
                + "\n",
                encoding="utf-8",
            )
        except (OSError, ValueError) as exc:
            print(f"withdrawal failed: {exc}", file=sys.stderr)
            return 2
        print(f"withdrawal: {output}")
        return 0

    try:
        manifest = load_manifest(args.manifest)
    except (OSError, ValueError) as exc:
        print(f"invalid manifest: {exc}", file=sys.stderr)
        return 2

    if not args.sdk_only:
        problems = _platform_problems(manifest, Path(args.manifest).resolve())
        if problems:
            print("manifest neprojde platformou:", file=sys.stderr)
            for problem in problems:
                print(f"  - {problem}", file=sys.stderr)
            return 2

    print(f"valid: {manifest.slug} {manifest.version}")
    if manifest.auth.type == "oauth_delegated":
        secrets = ", ".join(manifest.auth.runtime_secrets)
        print(
            f"auth: oauth_delegated provider={manifest.auth.provider} "
            f"runtime_secrets=[{secrets}]"
        )
    runtime = manifest.runtime
    if runtime.pii_salt or runtime.health_path or runtime.vault_ttl is not None:
        print(
            f"runtime: pii_salt={str(runtime.pii_salt).lower()} "
            f"health_path={runtime.health_path or '-'} "
            f"vault_ttl={runtime.vault_ttl if runtime.vault_ttl is not None else '-'}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
