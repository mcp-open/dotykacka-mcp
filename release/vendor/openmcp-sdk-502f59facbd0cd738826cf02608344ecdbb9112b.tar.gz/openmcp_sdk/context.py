"""Identita, přihlašovací údaje a konfigurace konektoru pro jeden request.

Transport vytvoří jeden neměnný :class:`RequestContext` pro každý request.
Nástroje konektoru k němu přistupují přes :func:`current_context`; identita
a secrets se jako argumenty nástroje nikdy nepřijímají.
"""

from __future__ import annotations

import re
from uuid import UUID, uuid4
from collections.abc import Callable, Mapping
from contextvars import ContextVar, Token
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Literal

from openmcp_sdk.envelope import ConnectorError, ErrorCode

if TYPE_CHECKING:
    from openmcp_sdk.oauth import DelegatedOAuthClient

_SUB_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:@+-]{0,254}$")


@dataclass(frozen=True)
class Principal:
    """Ověřený principal konektoru.

    ``sub`` je záměrně omezen na jediný path-safe segment pro Vault.
    Keycloak subjekty (UUID) i lokální/testovací subjekty tento kontrakt
    splňují; lomítka, řídicí znaky a traversal sekvence nikoliv.
    """

    sub: str
    email: str | None = None
    # Published HashiCorp Vault KV v2 version selected by the control plane.
    # Hosted runtimes must never infer this by reading ``latest``: a staged or
    # failed rotation may already have created a newer, unpublished version.
    credential_version: int | None = None
    credential_owner_kind: Literal["user", "team"] | None = None
    credential_owner_id: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.sub, str) or not _SUB_RE.fullmatch(self.sub):
            raise ConnectorError(ErrorCode.FORBIDDEN, "neplatná ověřená identita")
        if self.email is not None:
            if (
                not isinstance(self.email, str)
                or not self.email
                or len(self.email) > 320
                or any(ord(char) < 32 or ord(char) == 127 for char in self.email)
            ):
                raise ConnectorError(ErrorCode.FORBIDDEN, "neplatný ověřený e-mail")
        if self.credential_version is not None and (
            isinstance(self.credential_version, bool)
            or not isinstance(self.credential_version, int)
            or not 1 <= self.credential_version <= 2_147_483_647
        ):
            raise ConnectorError(
                ErrorCode.FORBIDDEN, "neplatná verze přihlašovacích údajů"
            )
        owner_values = (self.credential_owner_kind, self.credential_owner_id)
        if self.credential_version is None:
            if any(value is not None for value in owner_values):
                raise ConnectorError(
                    ErrorCode.FORBIDDEN, "neúplná identita přihlašovacích údajů"
                )
        else:
            if self.credential_owner_kind not in {"user", "team"} or not isinstance(
                self.credential_owner_id, str
            ):
                raise ConnectorError(
                    ErrorCode.FORBIDDEN, "neúplná identita přihlašovacích údajů"
                )
            try:
                canonical_owner = str(UUID(self.credential_owner_id))
            except (ValueError, AttributeError) as exc:
                raise ConnectorError(
                    ErrorCode.FORBIDDEN, "neplatný vlastník přihlašovacích údajů"
                ) from exc
            if canonical_owner != self.credential_owner_id:
                raise ConnectorError(
                    ErrorCode.FORBIDDEN, "neplatný vlastník přihlašovacích údajů"
                )
            if self.credential_owner_kind == "user" and self.credential_owner_id != self.sub:
                raise ConnectorError(
                    ErrorCode.FORBIDDEN, "nesprávný vlastník přihlašovacích údajů"
                )


class WriteDecision(str, Enum):
    """Co politika říká o konkrétním zápisu."""

    ALLOW = "allow"
    REQUIRE_APPROVAL = "require_approval"
    DENY = "deny"


@dataclass(frozen=True)
class AccessPolicy:
    """Autorizační politika pro nástroje konektoru na úrovni workspace."""

    mode: Literal["read_only", "allow_write", "approval_required", "disabled"] = (
        "read_only"
    )
    allowed_tools: frozenset[str] = frozenset()
    require_approval: bool = False

    def write_decision(self, tool_name: str) -> WriteDecision:
        """Rozhodnutí o zápisu včetně možnosti „ano, ale s potvrzením".

        Do 0.4 se ``mode="approval_required"`` chovalo přesně jako
        ``read_only`` (``can_call`` ho nikdy nepustilo) a pole
        ``require_approval`` nečetl nikdo — workspace, který si vyžádal
        „zápis s potvrzením", tak tiše dostal „žádný zápis".

        ``require_approval=True`` je **override, který přebije přepínač
        konektoru** ``require_write_confirmation=false``: operátor workspace
        může potvrzení vynutit, i když ho operátor konektora vypnul. Opačně
        to nejde — to je jediný způsob, jak toto pole není dekorace.
        """
        if self.mode == "disabled":
            return WriteDecision.DENY
        if self.allowed_tools and tool_name not in self.allowed_tools:
            return WriteDecision.DENY
        if self.mode == "read_only":
            return WriteDecision.DENY
        if self.mode == "approval_required":
            return WriteDecision.REQUIRE_APPROVAL
        return (
            WriteDecision.REQUIRE_APPROVAL
            if self.require_approval
            else WriteDecision.ALLOW
        )

    def can_call(self, tool_name: str, *, read_only: bool) -> bool:
        if self.mode == "disabled":
            return False
        if self.allowed_tools and tool_name not in self.allowed_tools:
            return False
        if not read_only:
            return self.write_decision(tool_name) is not WriteDecision.DENY
        return True


@dataclass(frozen=True)
class RequestContext:
    principal: Principal
    secrets: Mapping[str, str] = field(default_factory=dict)
    config: Mapping[str, Any] = field(default_factory=dict)
    invalidate_credentials: Callable[[], None] | None = field(
        default=None, repr=False, compare=False
    )
    request_id: str = field(default_factory=lambda: uuid4().hex)
    policy: AccessPolicy = field(default_factory=AccessPolicy)
    oauth: "DelegatedOAuthClient | None" = field(
        default=None, repr=False, compare=False
    )

    def __post_init__(self) -> None:
        # Providers cachují Resolved instance. Kopírování a zmrazení tady
        # brání tomu, aby jeden nástroj/request pozměnil credentials, které
        # pozoruje jiný.
        object.__setattr__(self, "secrets", MappingProxyType(dict(self.secrets)))
        object.__setattr__(self, "config", MappingProxyType(dict(self.config)))


_current: ContextVar[RequestContext | None] = ContextVar(
    "openmcp_request_context", default=None
)


def current_context() -> RequestContext:
    ctx = _current.get()
    if ctx is None:
        raise ConnectorError(ErrorCode.INTERNAL, "chybí request kontext")
    return ctx


def invalidate_current_credentials() -> bool:
    """Zneplatní credentials asociované s aktivním requestem, pokud jsou cachované.

    Upstream HTTP helpery tohle volají v místě, kde je skutečná upstream
    401 ještě pozorovatelná. Návratová hodnota bool usnadňuje testování
    a hodí se i pro vlastní klienty konektoru.
    """

    callback = current_context().invalidate_credentials
    if callback is None:
        return False
    callback()
    return True


def require_write_access(tool_name: str) -> None:
    """Odmítni zápis, pokud ho politika **bezpodmínečně** nepovoluje.

    ZÁMĚRNĚ přísnější než :meth:`AccessPolicy.can_call`: propouští jen
    ``ALLOW``, ne ``REQUIRE_APPROVAL``. Kdo volá jen tuto funkci, nemá jak
    potvrzení vyžádat — kdybychom ``REQUIRE_APPROVAL`` pustili, zápis by
    prošel nepotvrzený. Orchestrovaná cesta
    (:func:`openmcp_sdk.write.execute_write`) si rozhodnutí zjišťuje sama přes
    ``policy.write_decision()`` a potvrzení vynutí.
    """

    ctx = current_context()
    if ctx.policy.write_decision(tool_name) is not WriteDecision.ALLOW:
        raise ConnectorError(
            ErrorCode.FORBIDDEN, "zápis není povolen firemní politikou"
        )


def set_context(ctx: RequestContext) -> Token[RequestContext | None]:
    return _current.set(ctx)


def reset_context(token: Token[RequestContext | None]) -> None:
    _current.reset(token)
