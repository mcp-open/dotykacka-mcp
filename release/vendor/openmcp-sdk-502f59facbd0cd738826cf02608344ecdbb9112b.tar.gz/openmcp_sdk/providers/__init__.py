"""Registr OAuth providerů pro konektory s delegovaným OAuth.

:class:`Provider` umí vyměnit refresh token daného uživatele za krátkodobý
upstream access token. Konektory nikdy nekomunikují s providerem přímo; SDK
jej vyhledá podle ``manifest.auth.provider`` a zapojí do
:class:`openmcp_sdk.oauth.DelegatedOAuthClient`, který je vystavený jako
``current_context().oauth``.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from openmcp_sdk.envelope import ConnectorError, ErrorCode


@runtime_checkable
class Provider(Protocol):
    """Kontrakt pro výměnu tokenu v delegovaném OAuth.

    ``name`` je hodnota porovnávaná s ``manifest.auth.provider``. ``exchange``
    promění refresh token daného uživatele (a selektor tenanta specifický pro
    providera, jako je Dotykačkin ``cloud_id``) na ``(access_token, expires_in_seconds)``.
    """

    name: str

    def exchange(self, refresh_token: str, cloud_id: str) -> tuple[str, int]: ...


_REGISTRY: dict[str, Provider] = {}


def register_provider(provider: Provider) -> None:
    _REGISTRY[provider.name] = provider


def get_provider(name: str | None) -> Provider:
    if not name or name not in _REGISTRY:
        raise ConnectorError(
            ErrorCode.INTERNAL, f"neznámý OAuth provider: {name!r}"
        )
    return _REGISTRY[name]


def available_providers() -> tuple[str, ...]:
    return tuple(sorted(_REGISTRY))


# Registrace vestavěných providerů. Import je záměrně na konci souboru, aby
# se předešlo cyklu: ``dotykacka`` importuje protokol ``Provider`` definovaný výše.
from openmcp_sdk.providers.dotykacka import DotykackaProvider  # noqa: E402

register_provider(DotykackaProvider())

__all__ = [
    "Provider",
    "DotykackaProvider",
    "register_provider",
    "get_provider",
    "available_providers",
]
