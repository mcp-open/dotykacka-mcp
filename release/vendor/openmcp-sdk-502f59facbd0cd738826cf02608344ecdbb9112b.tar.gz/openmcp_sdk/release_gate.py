"""Fail-closed release evidence gate for connector distribution artifacts."""

from __future__ import annotations

import hashlib
import json
import re
import stat
import subprocess
import zipfile
from datetime import UTC, datetime, timedelta
from pathlib import Path, PurePosixPath
from typing import Any, Literal
from urllib.parse import urlsplit

import yaml
from pydantic import BaseModel, ConfigDict, Field as PydField
from pydantic import ValidationError, field_validator, model_validator

_GIT_SHA_RE = re.compile(r"^[0-9a-f]{40}$")
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_VULN_SEVERITIES = frozenset({"UNKNOWN", "LOW", "MEDIUM", "HIGH", "CRITICAL"})
_TARGETS = frozenset({"claude_mcpb", "openai_remote", "gemini_remote"})
_WINDOWS_RESERVED = frozenset(
    {"con", "prn", "aux", "nul"}
    | {f"com{index}" for index in range(1, 10)}
    | {f"lpt{index}" for index in range(1, 10)}
)


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


def _relative_path(value: str) -> str:
    path = Path(value)
    if (
        not value
        or "\\" in value
        or ":" in value
        or any(ord(char) < 32 for char in value)
        or path.is_absolute()
        or any(part in {"", ".", ".."} for part in path.parts)
        or any(
            part.endswith((" ", "."))
            or part.split(".", 1)[0].lower() in _WINDOWS_RESERVED
            for part in path.parts
        )
    ):
        raise ValueError("očekává se bezpečná přenositelná relativní cesta")
    return path.as_posix()


def _https_identifier(value: str) -> str:
    parsed = urlsplit(value)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or any(char.isspace() for char in value)
    ):
        raise ValueError(
            "očekává se HTTPS identifikátor bez credentials, query, fragmentu "
            "a whitespace"
        )
    return value.rstrip("/")


class ArtifactEvidence(_StrictModel):
    target: Literal["claude_mcpb", "openai_remote", "gemini_remote"]
    artifact: str
    sbom: str
    scan: str
    contents_manifest: str
    scan_targets: list[str]
    signature_bundle: str
    provenance: str
    provenance_bundle: str
    lockfiles: list[str] = PydField(default_factory=list)

    @field_validator(
        "artifact",
        "sbom",
        "scan",
        "contents_manifest",
        "signature_bundle",
        "provenance",
        "provenance_bundle",
    )
    @classmethod
    def _paths(cls, value: str) -> str:
        return _relative_path(value)

    @field_validator("lockfiles")
    @classmethod
    def _lockfiles(cls, values: list[str]) -> list[str]:
        normalized = [_relative_path(value) for value in values]
        if not normalized or len(normalized) != len(set(normalized)):
            raise ValueError("každý artefakt musí mít neprázdné unikátní lockfiles")
        return normalized

    @field_validator("scan_targets")
    @classmethod
    def _scan_targets(cls, values: list[str]) -> list[str]:
        normalized = [_relative_path(value) for value in values]
        if not normalized or len(normalized) != len(set(normalized)):
            raise ValueError("scan_targets musí být neprázdné a unikátní")
        return normalized


class GateConfig(_StrictModel):
    schema_version: Literal[1]
    source_repository: str
    builder_identity: str
    oidc_issuer: str = "https://token.actions.githubusercontent.com"
    trivy_version: str
    artifacts: list[ArtifactEvidence]
    high_approvals: str | None = None
    high_approvers: list[str] = PydField(default_factory=list)

    @field_validator("source_repository", "builder_identity", "oidc_issuer")
    @classmethod
    def _https(cls, value: str) -> str:
        return _https_identifier(value)

    @field_validator("high_approvals")
    @classmethod
    def _approval_path(cls, value: str | None) -> str | None:
        return _relative_path(value) if value is not None else None

    @field_validator("trivy_version")
    @classmethod
    def _trivy_version(cls, value: str) -> str:
        if not re.fullmatch(r"\d+\.\d+\.\d+", value):
            raise ValueError("trivy_version musí být přesná x.y.z verze")
        return value

    @field_validator("high_approvers")
    @classmethod
    def _high_approvers(cls, values: list[str]) -> list[str]:
        if len(values) != len(set(values)) or any(
            len(value) < 3
            or len(value) > 256
            or any(char in "\r\n\x00" for char in value)
            for value in values
        ):
            raise ValueError("high_approvers musí být unikátní konkrétní identity")
        return values

    @model_validator(mode="after")
    def _unique_artifacts(self) -> "GateConfig":
        if not self.artifacts:
            raise ValueError("release gate vyžaduje alespoň jeden artefakt")
        targets = [item.target for item in self.artifacts]
        paths = [item.artifact for item in self.artifacts]
        if len(targets) != len(set(targets)):
            raise ValueError("release gate obsahuje duplicitní target")
        if len(paths) != len(set(paths)):
            raise ValueError("release gate obsahuje duplicitní artifact path")
        expected_builder = (
            f"{self.source_repository}/.github/workflows/"
            "distribution-release.yml@refs/heads/main"
        )
        if self.builder_identity != expected_builder:
            raise ValueError(
                "builder_identity musí být main distribution-release workflow "
                "deklarovaného source repository"
            )
        if self.oidc_issuer != "https://token.actions.githubusercontent.com":
            raise ValueError("release gate v1 podporuje pouze GitHub Actions OIDC")
        return self


class HighApproval(_StrictModel):
    artifact_sha256: str
    vulnerability_id: str
    approved_by: str
    reason: str
    expires_at: datetime

    @field_validator("artifact_sha256")
    @classmethod
    def _digest(cls, value: str) -> str:
        if not _SHA256_RE.fullmatch(value):
            raise ValueError("artifact_sha256 musí být lowercase SHA-256")
        return value

    @field_validator("vulnerability_id", "approved_by", "reason")
    @classmethod
    def _nonempty(cls, value: str) -> str:
        if len(value) < 3:
            raise ValueError("schválení musí mít konkrétní hodnotu")
        return value

    @field_validator("expires_at")
    @classmethod
    def _timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("expires_at musí obsahovat timezone")
        return value.astimezone(UTC)


def _load_yaml(path: Path) -> Any:
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise ValueError(f"{path} se nedá načíst: {exc}") from exc


def load_gate(path: str | Path) -> GateConfig:
    source = Path(path)
    raw = _load_yaml(source)
    if not isinstance(raw, dict):
        raise ValueError(f"{source} musí být YAML mapa")
    try:
        return GateConfig.model_validate(raw)
    except ValidationError as exc:
        raise ValueError(f"neplatný release gate {source}: {exc}") from exc


def _resolve_file(root: Path, relative: str) -> Path:
    root = root.resolve()
    lexical = root / relative
    current = root
    for part in Path(relative).parts:
        current = current / part
        if current.is_symlink():
            raise ValueError(f"evidence path nesmí vést přes symlink: {relative}")
    candidate = lexical.resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"evidence path uniká z root: {relative}") from exc
    if not candidate.is_file():
        raise ValueError(f"evidence path není běžný soubor: {relative}")
    return candidate


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


_MAX_ARCHIVE_ENTRIES = 10_000
_MAX_ARCHIVE_FILE_BYTES = 128 * 1024 * 1024
_MAX_ARCHIVE_TOTAL_BYTES = 512 * 1024 * 1024


def _archive_payload(artifact: Path) -> tuple[str, list[dict[str, Any]]]:
    if not zipfile.is_zipfile(artifact):
        return (
            "file",
            [
                {
                    "path": artifact.name,
                    "sha256": _sha256(artifact),
                    "bytes": artifact.stat().st_size,
                }
            ],
        )

    entries: list[dict[str, Any]] = []
    seen: set[str] = set()
    total_bytes = 0
    with zipfile.ZipFile(artifact) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            raw_name = info.filename
            pure = PurePosixPath(raw_name)
            if (
                not raw_name
                or "\\" in raw_name
                or pure.is_absolute()
                or any(part in {"", ".", ".."} for part in pure.parts)
            ):
                raise ValueError(f"archive obsahuje nebezpečnou cestu: {raw_name!r}")
            name = pure.as_posix()
            if name in seen:
                raise ValueError(f"archive obsahuje duplicitní cestu: {name}")
            seen.add(name)
            if info.flag_bits & 0x1:
                raise ValueError(f"archive obsahuje šifrovanou položku: {name}")
            unix_type = (info.external_attr >> 16) & 0o170000
            if unix_type == stat.S_IFLNK:
                raise ValueError(f"archive obsahuje symlink: {name}")
            if info.file_size > _MAX_ARCHIVE_FILE_BYTES:
                raise ValueError(f"archive položka je příliš velká: {name}")
            total_bytes += info.file_size
            if (
                len(entries) >= _MAX_ARCHIVE_ENTRIES
                or total_bytes > _MAX_ARCHIVE_TOTAL_BYTES
            ):
                raise ValueError("archive překročil bezpečný počet nebo velikost")
            digest = hashlib.sha256()
            with archive.open(info) as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
            entries.append(
                {
                    "path": name,
                    "sha256": digest.hexdigest(),
                    "bytes": info.file_size,
                }
            )
    return "zip", sorted(entries, key=lambda item: item["path"])


def build_contents_manifest(
    *,
    artifact: str | Path,
    artifact_name: str,
    build_inputs: list[tuple[str, str | Path]],
) -> dict[str, Any]:
    artifact_path = Path(artifact)
    artifact_name = _relative_path(artifact_name)
    if artifact_path.is_symlink() or not artifact_path.is_file():
        raise ValueError("artifact pro content manifest neexistuje")
    normalized_inputs = [
        (_relative_path(name), Path(path)) for name, path in build_inputs
    ]
    input_names = [name for name, _ in normalized_inputs]
    if not normalized_inputs or len(input_names) != len(set(input_names)):
        raise ValueError("content manifest vyžaduje neprázdné unikátní build inputs")
    recorded_inputs: list[dict[str, Any]] = []
    for name, input_path in sorted(normalized_inputs):
        if input_path.is_symlink() or not input_path.is_file():
            raise ValueError(f"build input neexistuje: {name}")
        recorded_inputs.append(
            {
                "path": name,
                "sha256": _sha256(input_path),
                "bytes": input_path.stat().st_size,
            }
        )
    archive_format, payload = _archive_payload(artifact_path)
    return {
        "schema": "openmcp.artifact-contents.v1",
        "artifact": {
            "path": artifact_name,
            "sha256": _sha256(artifact_path),
            "bytes": artifact_path.stat().st_size,
            "format": archive_format,
        },
        "payload": payload,
        "build_inputs": recorded_inputs,
    }


def _validate_contents_manifest(
    manifest: Path,
    *,
    artifact: Path,
    artifact_relative: str,
    lockfiles: dict[str, Path],
) -> dict[str, int]:
    recorded = _load_json(manifest)
    if not isinstance(recorded, dict):
        raise ValueError("content manifest musí být JSON objekt")
    build_inputs = recorded.get("build_inputs")
    if not isinstance(build_inputs, list) or not build_inputs:
        raise ValueError("content manifest nemá build inputs")
    input_paths: list[str] = []
    actual_inputs: list[tuple[str, Path]] = []
    for item in build_inputs:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str):
            raise ValueError("content manifest má neplatný build input")
        name = _relative_path(item["path"])
        if name in input_paths or name not in lockfiles:
            raise ValueError(
                f"content manifest build input není unikátní provenance lock: {name}"
            )
        input_paths.append(name)
        actual_inputs.append((name, lockfiles[name]))
    expected = build_contents_manifest(
        artifact=artifact,
        artifact_name=artifact_relative,
        build_inputs=actual_inputs,
    )
    if recorded != expected:
        raise ValueError("content manifest neodpovídá přesnému artifact payloadu")
    return {
        "payload_files": len(expected["payload"]),
        "build_inputs": len(expected["build_inputs"]),
    }


def bind_trivy_report(
    *,
    report: str | Path,
    artifact_name: str,
    contents_manifest: str | Path,
    required_targets: list[str],
) -> dict[str, Any]:
    artifact_name = _relative_path(artifact_name)
    normalized_targets = [_relative_path(target) for target in required_targets]
    if not normalized_targets or len(normalized_targets) != len(
        set(normalized_targets)
    ):
        raise ValueError("Trivy binding vyžaduje unikátní required targets")
    report_path = Path(report)
    manifest_path = Path(contents_manifest)
    data = _load_json(report_path)
    manifest = _load_json(manifest_path)
    if not isinstance(data, dict) or not isinstance(manifest, dict):
        raise ValueError("Trivy report nebo content manifest není JSON objekt")
    results = data.get("Results")
    if not isinstance(results, list) or not results:
        raise ValueError("Trivy report neobsahuje žádný analyzovaný target")
    seen_targets = {
        result.get("Target")
        for result in results
        if isinstance(result, dict) and isinstance(result.get("Target"), str)
    }
    missing = sorted(set(normalized_targets) - seen_targets)
    if missing:
        raise ValueError(
            "Trivy report neobsahuje povinné targety: " + ", ".join(missing)
        )
    bound = dict(data)
    bound["ArtifactName"] = artifact_name
    bound["OpenMCP"] = {
        "SchemaVersion": 1,
        "ContentsManifestSHA256": _sha256(manifest_path),
        "RequiredTargets": normalized_targets,
    }
    return bound


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"{path} není platný JSON: {exc}") from exc


def _validate_spdx(path: Path, *, artifact_path: Path) -> dict[str, int]:
    data = _load_json(path)
    if not isinstance(data, dict):
        raise ValueError(f"SBOM {path} musí být JSON objekt")
    version = data.get("spdxVersion")
    namespace = data.get("documentNamespace")
    packages = data.get("packages", [])
    files = data.get("files", [])
    describes = data.get("documentDescribes", [])
    relationships = data.get("relationships", [])
    creation = data.get("creationInfo")
    if (
        version != "SPDX-2.3"
        or data.get("name") != artifact_path.name
        or not isinstance(namespace, str)
        or not namespace.startswith(("https://", "urn:"))
        or not isinstance(creation, dict)
        or not isinstance(packages, list)
        or not isinstance(files, list)
        or not isinstance(describes, list)
        or not isinstance(relationships, list)
        or (not packages and not files)
    ):
        raise ValueError(
            f"SBOM {path} není úplný Syft SPDX 2.3 dokument s popsaným obsahem"
        )
    identifiers = {
        item.get("SPDXID")
        for item in [*packages, *files]
        if isinstance(item, dict) and isinstance(item.get("SPDXID"), str)
    }
    relationship_describes = {
        item.get("relatedSpdxElement")
        for item in relationships
        if isinstance(item, dict)
        and item.get("spdxElementId") == "SPDXRef-DOCUMENT"
        and item.get("relationshipType") == "DESCRIBES"
    }
    described = set(describes) | relationship_describes
    if not described or any(item not in identifiers for item in described):
        raise ValueError(f"SBOM {path} documentDescribes odkazuje mimo obsah")
    artifact_digest = _sha256(artifact_path)
    described_items = [
        item
        for item in [*packages, *files]
        if isinstance(item, dict) and item.get("SPDXID") in described
    ]
    checksum_bound = any(
        item.get("name") == artifact_path.name
        and any(
            isinstance(checksum, dict)
            and checksum.get("algorithm") == "SHA256"
            and checksum.get("checksumValue") == artifact_digest
            for checksum in item.get("checksums", [])
        )
        for item in described_items
    )
    if not checksum_bound:
        raise ValueError(f"SBOM {path} není SHA-256 svázaný s přesným artefaktem")
    return {"packages": len(packages), "files": len(files)}


def _scan_findings(
    path: Path,
    *,
    artifact_relative: str,
    artifact_path: Path,
    contents_manifest: Path,
    required_targets: list[str],
    trivy_version: str,
) -> list[dict[str, str]]:
    data = _load_json(path)
    if not isinstance(data, dict):
        raise ValueError(f"Trivy report {path} musí být JSON objekt")
    artifact_name = data.get("ArtifactName")
    accepted_names = {
        artifact_relative,
        Path(artifact_relative).as_posix(),
        str(artifact_path),
    }
    if artifact_name not in accepted_names:
        raise ValueError(
            f"Trivy report {path} není svázaný s artefaktem {artifact_relative}"
        )
    results = data.get("Results", [])
    trivy = data.get("Trivy")
    binding = data.get("OpenMCP")
    if (
        data.get("SchemaVersion") != 2
        or not isinstance(trivy, dict)
        or trivy.get("Version") != trivy_version
        or not isinstance(results, list)
        or not results
        or not isinstance(binding, dict)
        or binding.get("SchemaVersion") != 1
        or binding.get("ContentsManifestSHA256") != _sha256(contents_manifest)
        or binding.get("RequiredTargets") != required_targets
    ):
        raise ValueError(
            f"Trivy report {path} nemá platné schema, targets nebo content binding"
        )
    seen_targets = {
        result.get("Target")
        for result in results
        if isinstance(result, dict) and isinstance(result.get("Target"), str)
    }
    missing_targets = sorted(set(required_targets) - seen_targets)
    if missing_targets:
        raise ValueError(
            f"Trivy report {path} neobsahuje povinné targety: "
            + ", ".join(missing_targets)
        )
    found: list[dict[str, str]] = []
    for result in results:
        if not isinstance(result, dict):
            raise ValueError(f"Trivy report {path} obsahuje neplatný result")
        vulnerabilities = result.get("Vulnerabilities") or []
        if not isinstance(vulnerabilities, list):
            raise ValueError(f"Trivy report {path} má neplatné Vulnerabilities")
        for vulnerability in vulnerabilities:
            if not isinstance(vulnerability, dict):
                raise ValueError(f"Trivy report {path} obsahuje neplatný nález")
            vuln_id = vulnerability.get("VulnerabilityID")
            severity = vulnerability.get("Severity")
            if (
                not isinstance(vuln_id, str)
                or not isinstance(severity, str)
                or severity.upper() not in _VULN_SEVERITIES
            ):
                raise ValueError(f"Trivy report {path} obsahuje neúplný nález")
            found.append({"id": vuln_id, "severity": severity.upper()})
        secrets = result.get("Secrets") or []
        if not isinstance(secrets, list):
            raise ValueError(f"Trivy report {path} má neplatné Secrets")
        for secret in secrets:
            if not isinstance(secret, dict):
                raise ValueError(f"Trivy report {path} obsahuje neplatný secret nález")
            rule_id = secret.get("RuleID")
            if not isinstance(rule_id, str) or not rule_id:
                raise ValueError(f"Trivy report {path} obsahuje neúplný secret nález")
            found.append({"id": f"SECRET:{rule_id}", "severity": "CRITICAL"})
        misconfigurations = result.get("Misconfigurations") or []
        if not isinstance(misconfigurations, list):
            raise ValueError(f"Trivy report {path} má neplatné Misconfigurations")
        for misconfiguration in misconfigurations:
            if not isinstance(misconfiguration, dict):
                raise ValueError(
                    f"Trivy report {path} obsahuje neplatný misconfiguration nález"
                )
            status = misconfiguration.get("Status")
            if status == "PASS":
                continue
            finding_id = misconfiguration.get("ID")
            severity = misconfiguration.get("Severity")
            if (
                status != "FAIL"
                or not isinstance(finding_id, str)
                or not finding_id
                or not isinstance(severity, str)
                or severity.upper() not in _VULN_SEVERITIES
            ):
                raise ValueError(
                    f"Trivy report {path} obsahuje neúplný misconfiguration nález"
                )
            found.append(
                {
                    "id": f"MISCONFIG:{finding_id}",
                    "severity": severity.upper(),
                }
            )
    return found


def _load_approvals(path: Path | None) -> list[HighApproval]:
    if path is None:
        return []
    raw = _load_yaml(path)
    if not isinstance(raw, list):
        raise ValueError("high approvals musí být YAML seznam")
    try:
        return [HighApproval.model_validate(item) for item in raw]
    except ValidationError as exc:
        raise ValueError(f"neplatné high severity schválení: {exc}") from exc


def _run_cosign(
    cosign_binary: str,
    payload: Path,
    bundle: Path,
    *,
    identity: str,
    issuer: str,
) -> None:
    command = [
        cosign_binary,
        "verify-blob",
        str(payload),
        "--bundle",
        str(bundle),
        "--certificate-identity",
        identity,
        "--certificate-oidc-issuer",
        issuer,
    ]
    try:
        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=120,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ValueError(f"cosign ověření se nepodařilo spustit: {exc}") from exc
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip()
        raise ValueError(f"cosign verify-blob selhalo pro {payload.name}: {detail}")


def _validate_provenance(
    path: Path,
    *,
    artifact_name: str,
    artifact_digest: str,
    source_repository: str,
    source_commit: str,
    builder_identity: str,
    target: str,
    lock_digests: dict[str, str],
) -> None:
    statement = _load_json(path)
    if not isinstance(statement, dict):
        raise ValueError("provenance musí být in-toto JSON objekt")
    if (
        statement.get("_type") != "https://in-toto.io/Statement/v1"
        or statement.get("predicateType") != "https://slsa.dev/provenance/v1"
    ):
        raise ValueError("provenance musí být in-toto v1 se SLSA provenance v1")
    subjects = statement.get("subject")
    expected_subject = {
        "name": artifact_name,
        "digest": {"sha256": artifact_digest},
    }
    if not isinstance(subjects, list) or expected_subject not in subjects:
        raise ValueError("provenance subject není svázaný s přesným artefaktem")
    predicate = statement.get("predicate")
    if not isinstance(predicate, dict):
        raise ValueError("provenance nemá predicate")
    definition = predicate.get("buildDefinition")
    details = predicate.get("runDetails")
    if not isinstance(definition, dict) or not isinstance(details, dict):
        raise ValueError("provenance nemá buildDefinition/runDetails")
    if definition.get(
        "buildType"
    ) != "https://openmcp.cz/build-types/connector-distribution/v1" or definition.get(
        "externalParameters"
    ) != {"target": target}:
        raise ValueError("provenance buildType nebo target nesouhlasí")
    builder = details.get("builder")
    if not isinstance(builder, dict) or builder.get("id") != builder_identity:
        raise ValueError("provenance builder identity nesouhlasí s release policy")
    dependencies = definition.get("resolvedDependencies")
    if not isinstance(dependencies, list):
        raise ValueError("provenance nemá resolvedDependencies")
    source_uri = f"git+{source_repository}"
    if {
        "uri": source_uri,
        "digest": {"gitCommit": source_commit},
    } not in dependencies:
        raise ValueError("provenance není svázaná s přesným source commitem")
    for lock_name, digest in lock_digests.items():
        if {
            "uri": f"file:{lock_name}",
            "digest": {"sha256": digest},
        } not in dependencies:
            raise ValueError(f"provenance neobsahuje lockfile {lock_name}")


def verify_release_gate(
    config_path: str | Path,
    *,
    root: str | Path,
    source_commit: str,
    output: str | Path,
    cosign_binary: str = "cosign",
    now: datetime | None = None,
) -> dict[str, Any]:
    if not _GIT_SHA_RE.fullmatch(source_commit):
        raise ValueError("source_commit musí být přesný lowercase 40 znakový Git SHA")
    config = load_gate(config_path)
    root_path = Path(root).resolve()
    approval_path = (
        _resolve_file(root_path, config.high_approvals)
        if config.high_approvals is not None
        else None
    )
    approvals = _load_approvals(approval_path)
    current_time = (now or datetime.now(UTC)).astimezone(UTC)
    evidence: list[dict[str, Any]] = []

    for item in config.artifacts:
        artifact = _resolve_file(root_path, item.artifact)
        sbom = _resolve_file(root_path, item.sbom)
        scan = _resolve_file(root_path, item.scan)
        contents_manifest = _resolve_file(root_path, item.contents_manifest)
        signature = _resolve_file(root_path, item.signature_bundle)
        provenance = _resolve_file(root_path, item.provenance)
        provenance_signature = _resolve_file(root_path, item.provenance_bundle)
        lockfiles = {
            relative: _resolve_file(root_path, relative) for relative in item.lockfiles
        }
        for evidence_name, evidence_path in (
            (item.sbom, sbom),
            (item.scan, scan),
            (item.contents_manifest, contents_manifest),
        ):
            if evidence_name in lockfiles:
                raise ValueError(
                    f"{item.target} nesmí duplikovat {evidence_name} mezi lockfiles"
                )
            lockfiles[evidence_name] = evidence_path
        artifact_digest = _sha256(artifact)
        lock_digests = {name: _sha256(path) for name, path in lockfiles.items()}
        sbom_summary = _validate_spdx(sbom, artifact_path=artifact)
        contents_summary = _validate_contents_manifest(
            contents_manifest,
            artifact=artifact,
            artifact_relative=item.artifact,
            lockfiles=lockfiles,
        )
        findings = _scan_findings(
            scan,
            artifact_relative=item.artifact,
            artifact_path=artifact,
            contents_manifest=contents_manifest,
            required_targets=item.scan_targets,
            trivy_version=config.trivy_version,
        )
        critical = [
            finding["id"] for finding in findings if finding["severity"] == "CRITICAL"
        ]
        if critical:
            raise ValueError(
                f"{item.target} blokují CRITICAL zranitelnosti: {', '.join(sorted(critical))}"
            )
        for finding in findings:
            if finding["severity"] != "HIGH":
                continue
            matching = [
                approval
                for approval in approvals
                if approval.artifact_sha256 == artifact_digest
                and approval.vulnerability_id == finding["id"]
                and approval.approved_by in config.high_approvers
                and approval.expires_at > current_time
                and approval.expires_at <= current_time + timedelta(days=30)
            ]
            if len(matching) != 1:
                raise ValueError(
                    f"{item.target} HIGH {finding['id']} nemá právě jedno "
                    "platné časově omezené schválení pro tento digest"
                )
            if config.high_approvals not in item.lockfiles:
                raise ValueError(
                    f"{item.target} HIGH schválení není zahrnuté mezi "
                    "provenance lockfiles"
                )

        _run_cosign(
            cosign_binary,
            artifact,
            signature,
            identity=config.builder_identity,
            issuer=config.oidc_issuer,
        )
        _run_cosign(
            cosign_binary,
            provenance,
            provenance_signature,
            identity=config.builder_identity,
            issuer=config.oidc_issuer,
        )
        _validate_provenance(
            provenance,
            artifact_name=item.artifact,
            artifact_digest=artifact_digest,
            source_repository=config.source_repository,
            source_commit=source_commit,
            builder_identity=config.builder_identity,
            target=item.target,
            lock_digests=lock_digests,
        )
        severity_counts = {
            severity: sum(1 for finding in findings if finding["severity"] == severity)
            for severity in sorted(_VULN_SEVERITIES)
        }
        evidence.append(
            {
                "target": item.target,
                "artifact": item.artifact,
                "sha256": artifact_digest,
                "bytes": artifact.stat().st_size,
                "sbom": {
                    "path": item.sbom,
                    "sha256": _sha256(sbom),
                    **sbom_summary,
                },
                "scan": {
                    "path": item.scan,
                    "sha256": _sha256(scan),
                    "severity_counts": severity_counts,
                },
                "contents": {
                    "path": item.contents_manifest,
                    "sha256": _sha256(contents_manifest),
                    **contents_summary,
                },
                "locks": [
                    {"path": name, "sha256": digest}
                    for name, digest in sorted(lock_digests.items())
                ],
                "signature": {
                    "status": "verified",
                    "bundle": item.signature_bundle,
                    "bundle_sha256": _sha256(signature),
                },
                "provenance": {
                    "status": "verified",
                    "path": item.provenance,
                    "sha256": _sha256(provenance),
                    "bundle": item.provenance_bundle,
                    "bundle_sha256": _sha256(provenance_signature),
                },
            }
        )

    result = {
        "schema": "openmcp.release-evidence.v1",
        "status": "eligible",
        "source": {
            "repository": config.source_repository,
            "commit": source_commit,
            "builder": config.builder_identity,
        },
        "verified_at": current_time.isoformat().replace("+00:00", "Z"),
        "artifacts": evidence,
    }
    output_path = Path(output)
    if output_path.exists():
        raise ValueError(f"release evidence output už existuje: {output_path}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return result


def build_provenance_statement(
    *,
    artifact: str | Path,
    artifact_name: str,
    source_repository: str,
    source_commit: str,
    builder_identity: str,
    invocation_id: str,
    target: str,
    lockfiles: list[tuple[str, str | Path]],
) -> dict[str, Any]:
    if not _GIT_SHA_RE.fullmatch(source_commit):
        raise ValueError("source_commit musí být přesný lowercase 40 znakový Git SHA")
    artifact_name = _relative_path(artifact_name)
    source_repository = _https_identifier(source_repository)
    builder_identity = _https_identifier(builder_identity)
    invocation_id = _https_identifier(invocation_id)
    if target not in _TARGETS:
        raise ValueError(f"neplatný release target: {target}")
    artifact_path = Path(artifact)
    if artifact_path.is_symlink() or not artifact_path.is_file():
        raise ValueError("artifact pro provenance neexistuje")
    normalized_locks = [(_relative_path(name), Path(path)) for name, path in lockfiles]
    lock_names = [name for name, _ in normalized_locks]
    if not normalized_locks or len(lock_names) != len(set(lock_names)):
        raise ValueError("provenance vyžaduje neprázdné unikátní lockfiles")
    dependencies = [
        {
            "uri": f"git+{source_repository}",
            "digest": {"gitCommit": source_commit},
        }
    ]
    for name, path in sorted(normalized_locks):
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"lockfile pro provenance neexistuje: {name}")
        dependencies.append(
            {"uri": f"file:{name}", "digest": {"sha256": _sha256(path)}}
        )
    return {
        "_type": "https://in-toto.io/Statement/v1",
        "subject": [
            {"name": artifact_name, "digest": {"sha256": _sha256(artifact_path)}}
        ],
        "predicateType": "https://slsa.dev/provenance/v1",
        "predicate": {
            "buildDefinition": {
                "buildType": "https://openmcp.cz/build-types/connector-distribution/v1",
                "externalParameters": {"target": target},
                "internalParameters": {},
                "resolvedDependencies": dependencies,
            },
            "runDetails": {
                "builder": {"id": builder_identity},
                "metadata": {"invocationId": invocation_id},
            },
        },
    }


def build_withdrawal_statement(
    *,
    release_evidence: str | Path,
    evidence_bundle: str | Path,
    release_reference: str,
    reason: str,
    actor: str,
    certificate_identity: str,
    oidc_issuer: str,
    cosign_binary: str = "cosign",
    incident_url: str | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    evidence_path = Path(release_evidence)
    bundle_path = Path(evidence_bundle)
    if (
        evidence_path.is_symlink()
        or bundle_path.is_symlink()
        or not evidence_path.is_file()
        or not bundle_path.is_file()
    ):
        raise ValueError("release evidence pro withdrawal neexistuje")
    certificate_identity = _https_identifier(certificate_identity)
    oidc_issuer = _https_identifier(oidc_issuer)
    _run_cosign(
        cosign_binary,
        evidence_path,
        bundle_path,
        identity=certificate_identity,
        issuer=oidc_issuer,
    )
    evidence = _load_json(evidence_path)
    if (
        not isinstance(evidence, dict)
        or evidence.get("schema") != "openmcp.release-evidence.v1"
        or evidence.get("status") != "eligible"
    ):
        raise ValueError("withdrawal vyžaduje eligible OpenMCP release evidence")
    artifacts = evidence.get("artifacts")
    if not isinstance(artifacts, list) or not artifacts:
        raise ValueError("release evidence nemá artefakty")
    source = evidence.get("source")
    if not isinstance(source, dict):
        raise ValueError("release evidence nemá platný source")
    source_repository = source.get("repository")
    source_commit = source.get("commit")
    source_builder = source.get("builder")
    if (
        not isinstance(source_repository, str)
        or _https_identifier(source_repository) != source_repository
        or not isinstance(source_commit, str)
        or not _GIT_SHA_RE.fullmatch(source_commit)
        or source_builder != certificate_identity
    ):
        raise ValueError("release evidence source nesouhlasí s ověřenou identitou")
    withdrawn_artifacts: list[dict[str, str]] = []
    for item in artifacts:
        if not isinstance(item, dict):
            raise ValueError("release evidence obsahuje neplatný artefakt")
        target = item.get("target")
        artifact = item.get("artifact")
        digest = item.get("sha256")
        if (
            target not in _TARGETS
            or not isinstance(artifact, str)
            or _relative_path(artifact) != artifact
            or not isinstance(digest, str)
            or not _SHA256_RE.fullmatch(digest)
        ):
            raise ValueError("release evidence obsahuje neúplný artefakt")
        withdrawn_artifacts.append(
            {"target": target, "artifact": artifact, "sha256": digest}
        )
    if not 3 <= len(release_reference) <= 256 or any(
        char.isspace() for char in release_reference
    ):
        raise ValueError(
            "release_reference musí být stabilní identifikátor bez whitespace"
        )
    if not 3 <= len(actor) <= 256 or any(char in "\r\n\x00" for char in actor):
        raise ValueError("actor musí být konkrétní jednořádková identita")
    if not 10 <= len(reason) <= 2_000 or any(char in "\x00" for char in reason):
        raise ValueError("withdrawal reason musí mít 10 až 2000 znaků")
    normalized_incident = (
        _https_identifier(incident_url) if incident_url is not None else None
    )
    current_time = (now or datetime.now(UTC)).astimezone(UTC)
    return {
        "schema": "openmcp.release-withdrawal.v1",
        "status": "withdrawn",
        "release_reference": release_reference,
        "release_evidence": {
            "path": evidence_path.name,
            "sha256": _sha256(evidence_path),
        },
        "source": source,
        "artifacts": withdrawn_artifacts,
        "reason": reason,
        "actor": actor,
        "incident_url": normalized_incident,
        "withdrawn_at": current_time.isoformat().replace("+00:00", "Z"),
    }
