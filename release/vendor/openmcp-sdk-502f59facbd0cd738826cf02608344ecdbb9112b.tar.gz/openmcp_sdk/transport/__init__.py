"""openmcp_sdk.transport — ASGI (:8000/mcp) a stdio transport pro connectory."""
