"""Jednouživatelský stdio transport."""

from __future__ import annotations

from openmcp_sdk.context import RequestContext, reset_context, set_context
from openmcp_sdk.manifest import Manifest
from openmcp_sdk.oauth import build_delegated_oauth


def run_stdio(mcp, identity, creds, manifest: Manifest | None = None) -> None:
    principal = identity.principal_from_headers({})
    resolved = creds.resolve(principal)
    invalidate = getattr(creds, "invalidate", None)
    callback = (lambda: invalidate(principal.sub)) if callable(invalidate) else None
    token = set_context(
        RequestContext(
            principal,
            resolved.secrets,
            resolved.config,
            invalidate_credentials=callback,
            oauth=build_delegated_oauth(manifest, resolved.secrets),
        )
    )
    try:
        mcp.run()
    finally:
        reset_context(token)
