"""Bezpečné a konzistentní mapování selhání upstream ``httpx``.

.. deprecated:: 0.4.0
   Obsah se přesunul do :mod:`openmcp_sdk.http`, který ho volá sám uvnitř
   ``UpstreamClient.request()``. Tento modul zůstává jako re-export, aby se
   existující importy nerozbily; odstraní se v 0.5.

   Důvod přesunu: modul tu byl od 0.2, ale **žádný konektor ho nepoužíval** —
   každý si napsal vlastní chybovou hierarchii (``RaynetError``,
   ``DotykackaError``, ``UpgatesError``), protože SDK tehdy nenabízelo klienta,
   který by mapování dělal za něj. Teď ho už používá každý, aniž by o něm
   věděl.
"""

from __future__ import annotations

import warnings

from openmcp_sdk.http import map_http_exc, raise_for_status

warnings.warn(
    "openmcp_sdk.http_errors je zastaralý, importuj z openmcp_sdk.http "
    "(odstranění v 0.5)",
    DeprecationWarning,
    stacklevel=2,
)

__all__ = ["map_http_exc", "raise_for_status"]
