"""Registrace MCP nástrojů s vynucenou anotací read-only.

Konektory dnes registrují nástroje dvěma různými způsoby:

* ``mcp.tool(fn, annotations=ToolAnnotations(readOnlyHint=True))`` pod funkcí
  (template, raynet, dotykacka, upgates) — funguje, ale registrace je vizuálně
  vzdálená od funkce, při 32 nástrojích se snadno zapomene a ``annotations=``
  je volitelné;
* dekorátor na tenkém wrapperu nad business funkcí (ares) — každý nástroj
  pak existuje **dvakrát** s duplikovaným podpisem i docstringem, a test
  cvičí jiný objekt, než je zaregistrovaný.

:func:`tool` obě cesty nahrazuje. Tři vlastnosti, na kterých záleží:

1. **Vrací původní funkci**, ne ``FunctionTool`` — v unit testu se dá
   zavolat přímo. Přesně ten důvod, pro který ``template/server.py`` volí plain
   funkci, jen jednou vyřešený v SDK místo komentáře v každém repozitáři.
2. **``read_only`` je povinný keyword bez defaultu.** Nástroj se nedá
   zaregistrovat bez rozhodnutí o anotaci. Bezpečnostní hranice se tím
   posouvá z běhu (kde se chybějící anotace projeví tichým zmizením nástroje
   přes fail-closed filter) do času psaní kódu.
3. ``destructive=True`` nastaví ``destructiveHint`` — odliší přepis od
   založení.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeVar

from mcp.types import ToolAnnotations

F = TypeVar("F", bound=Callable[..., Any])


def tool(
    mcp: Any,
    *,
    read_only: bool,
    destructive: bool = False,
    idempotent: bool | None = None,
    name: str | None = None,
    title: str | None = None,
    description: str | None = None,
) -> Callable[[F], F]:
    """Zaregistruj funkci jako MCP nástroj a vrať ji **nezměněnou**.

    ``read_only`` nemá default záměrně — viď docstring modulu.

    Příklad::

        @tool(mcp, read_only=True)
        def search_orders(query: str, limit: int = 20) -> OrdersEnvelope:
            \"\"\"Jedna definice, jeden docstring, jeden testovatelný objekt.\"\"\"
    """
    if not isinstance(read_only, bool):
        raise TypeError("read_only musí být bool — anotace je bezpečnostní hranice")
    if read_only and destructive:
        raise ValueError("read_only nástroj nemůže být destructive")

    annotations = ToolAnnotations(
        readOnlyHint=read_only,
        destructiveHint=destructive,
        idempotentHint=idempotent,
    )

    def decorate(fn: F) -> F:
        mcp.tool(
            fn,
            name=name or fn.__name__,
            annotations=annotations,
            **({"title": title} if title is not None else {}),
            **({"description": description} if description is not None else {}),
        )
        # Vracíme původní funkci, ne návratovou hodnotu `mcp.tool` — jinak by
        # se z modulového jména stal `FunctionTool`, který se nedá zavolat.
        return fn

    return decorate


__all__ = ["tool"]
