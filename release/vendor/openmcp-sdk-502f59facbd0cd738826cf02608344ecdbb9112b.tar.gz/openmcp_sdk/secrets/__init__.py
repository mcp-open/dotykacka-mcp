"""openmcp_sdk.secrets — řešení přihlašovacích údajů (lokálně i hostovaně)."""

from openmcp_sdk.secrets.vault import AsyncVaultProvider, VaultProvider

__all__ = ["AsyncVaultProvider", "VaultProvider"]
