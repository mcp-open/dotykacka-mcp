"""Thread-safe ohraničená TTL cache se singleflightem podle klíče."""

from __future__ import annotations

import threading
import time
from collections import OrderedDict
from collections.abc import Callable
from dataclasses import dataclass
from typing import Generic, TypeVar, cast

T = TypeVar("T")


@dataclass
class _Flight:
    lock: threading.Lock
    users: int = 0


class TTLCache(Generic[T]):
    def __init__(
        self,
        *,
        max_entries: int = 1024,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if max_entries <= 0:
            raise ValueError("max_entries musí být kladné")
        self._max_entries = max_entries
        self._clock = clock
        self._store: OrderedDict[str, tuple[T, float]] = OrderedDict()
        self._lock = threading.Lock()
        self._flights: dict[str, _Flight] = {}

    def _fresh_locked(self, key: str, now: float) -> T | None:
        entry = self._store.get(key)
        if entry is None:
            return None
        if entry[1] <= now:
            self._store.pop(key, None)
            return None
        self._store.move_to_end(key)
        return entry[0]

    def _join_flight(self, key: str) -> _Flight:
        with self._lock:
            flight = self._flights.get(key)
            if flight is None:
                flight = _Flight(threading.Lock())
                self._flights[key] = flight
            flight.users += 1
            return flight

    def _leave_flight(self, key: str, flight: _Flight) -> None:
        with self._lock:
            flight.users -= 1
            if flight.users == 0 and self._flights.get(key) is flight:
                self._flights.pop(key, None)

    def get_or_load(
        self,
        key: str,
        loader: Callable[[], T],
        ttl: float,
        now: float | None = None,
    ) -> T:
        if ttl < 0:
            raise ValueError("ttl nesmí být záporné")
        current = self._clock() if now is None else now
        with self._lock:
            cached = self._fresh_locked(key, current)
        if cached is not None:
            return cached

        flight = self._join_flight(key)
        try:
            with flight.lock:
                # Po čekání znovu změř čas. Tím se zabrání přijetí položky,
                # která mezitím vypršela, zatímco jiný volající načítal stejný klíč.
                current = self._clock() if now is None else now
                with self._lock:
                    cached = self._fresh_locked(key, current)
                if cached is not None:
                    return cached

                value = loader()
                stored_at = self._clock() if now is None else now
                with self._lock:
                    self._store[key] = (value, stored_at + ttl)
                    self._store.move_to_end(key)
                    while len(self._store) > self._max_entries:
                        self._store.popitem(last=False)
                return value
        finally:
            self._leave_flight(key, flight)

    def invalidate(self, key: str) -> None:
        with self._lock:
            self._store.pop(key, None)

    def invalidate_prefix(self, prefix: str) -> None:
        """Invalidate all cached values for one bounded key namespace."""

        with self._lock:
            for key in tuple(self._store):
                if key.startswith(prefix):
                    self._store.pop(key, None)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()

    def __len__(self) -> int:
        with self._lock:
            return len(self._store)

    def peek(self, key: str) -> T | None:
        """Vrať čerstvou hodnotu z cache bez načítání (diagnostika/testy)."""

        with self._lock:
            return cast(T | None, self._fresh_locked(key, self._clock()))
