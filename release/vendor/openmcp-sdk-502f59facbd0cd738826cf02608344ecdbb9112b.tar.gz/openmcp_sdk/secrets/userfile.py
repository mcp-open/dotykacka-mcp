"""Poskytovatel přihlašovacích údajů pro lokální multi-user JSON soubor."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from openmcp_sdk.context import Principal
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.manifest import Manifest
from openmcp_sdk.secrets.base import Resolved, resolve_fields


class UserFileProvider:
    def __init__(
        self,
        manifest: Manifest,
        path: str,
        environ: Mapping[str, str] | None = None,
    ) -> None:
        self._manifest = manifest
        self._path = path
        self._environ = environ

    def resolve(self, principal: Principal) -> Resolved:
        try:
            with open(self._path, encoding="utf-8") as file:
                data: Any = json.load(file)
        except (OSError, json.JSONDecodeError) as exc:
            raise ConnectorError(
                ErrorCode.INTERNAL, "soubor uživatelských credentials se nedá načíst"
            ) from exc
        if not isinstance(data, dict):
            raise ConnectorError(
                ErrorCode.INTERNAL, "neplatný soubor uživatelských credentials"
            )

        entry = data.get(principal.email) if principal.email else None
        if entry is None:
            raise ConnectorError(ErrorCode.FORBIDDEN, "nemáš přiřazený přístup")
        if not isinstance(entry, dict):
            raise ConnectorError(
                ErrorCode.INTERNAL, "neplatný záznam uživatelských credentials"
            )
        return resolve_fields(
            self._manifest,
            entry,
            environ=self._environ,
            reject_unknown=True,
            location="user file",
        )

    def invalidate(self, sub: str) -> None:
        del sub
