"""openmcp_sdk._version — jediný zdroj pravdy pro běžící verzi SDK.

Samostatný modul (ne `__init__.py`), aby `runtime.py` mohl importovat
`__version__` bez cyklického importu přes balíčkový `__init__.py`.
"""

__version__ = "0.4.2"
