"""Test harness pro konektory.

Do 0.4 to bylo 24 řádků s jediným ``with_context``, který neuměl ani
``policy``, ani ``oauth`` — takže se s ním nedalo otestovat write-gating ani
delegovaný OAuth. Rozšířené o dvojníky (:class:`FakeOAuth`,
:class:`FakeElicitation`), pytest plugin se sdílenými fixtures a
:class:`~openmcp_sdk.testing.conformance.ConnectorConformance` — sadu testů,
kterou si každý konektor pustí proti svému manifestu.
"""

from __future__ import annotations

from openmcp_sdk.testing.doubles import FakeElicitation, FakeOAuth, elicitation
from openmcp_sdk.testing.harness import with_context

__all__ = [
    "FakeElicitation",
    "FakeOAuth",
    "elicitation",
    "with_context",
]
