"""Pytest plugin se sdílenými fixtures pro konektory.

Registruje se přes entry point ``pytest11``, takže stačí mít SDK
nainstalované — konektor nepotřebuje žádný ``conftest.py``. Tři konektory
dnes mají `conftest.py` doslova identický.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import pytest

from openmcp_sdk.pii import SALT_ENV
from openmcp_sdk.testing.doubles import FakeElicitation, FakeOAuth, elicitation
from openmcp_sdk.write import DEFAULT_BUDGET

#: Deterministický salt pro testy. Nesmí se zhodovať s ničím prevádzkovým.
TEST_PII_SALT = "test-pii-salt"


@pytest.fixture(autouse=True)
def openmcp_pii_salt(monkeypatch: pytest.MonkeyPatch) -> str:
    """Nastav PII salt pro každý test.

    Autouse záměrně: bez saltu je `require_salt()` fail-closed a testy by
    padali na niečom, co není predmetom testu.
    """
    monkeypatch.setenv(SALT_ENV, TEST_PII_SALT)
    return TEST_PII_SALT


@pytest.fixture(autouse=True)
def openmcp_write_budget() -> Iterator[None]:
    """Vyprázdni sdílený rozpočet zápisů před i po každém testu.

    `DEFAULT_BUDGET` je modulová instance, takže bez toho se započítané
    zápisy přelévají mezi testy — sada pak po pár desítkách testů
    narazí na limit a začne padat na `FORBIDDEN` v místě, které s příčinou
    nesouvisí.
    """
    DEFAULT_BUDGET.reset()
    yield
    DEFAULT_BUDGET.reset()


@pytest.fixture
def anyio_backend() -> str:
    return "asyncio"


@pytest.fixture
def fake_oauth() -> FakeOAuth:
    return FakeOAuth()


@pytest.fixture
def fake_elicitation() -> Iterator[FakeElicitation]:
    """Klient, který potvrzení zápisu přijme; zprávy jsou v ``.messages``."""
    with elicitation("accept") as fake:
        yield fake


@pytest.fixture
def elicitation_factory() -> Any:
    """Pro testy, které potřebují jiné chování než ``accept``."""
    return elicitation
