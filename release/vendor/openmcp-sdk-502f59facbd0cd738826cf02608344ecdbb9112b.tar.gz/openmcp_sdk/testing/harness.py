"""Nastavení request kontextu v testoch."""

from __future__ import annotations

from collections.abc import Callable, Iterator, Mapping
from contextlib import contextmanager
from typing import Any

from openmcp_sdk.context import (
    AccessPolicy,
    Principal,
    RequestContext,
    reset_context,
    set_context,
)


@contextmanager
def with_context(
    secrets: Mapping[str, str] | None = None,
    config: Mapping[str, Any] | None = None,
    sub: str = "test",
    email: str | None = None,
    *,
    policy: AccessPolicy | None = None,
    oauth: Any = None,
    request_id: str = "test-request",
    invalidate_credentials: Callable[[], None] | None = None,
) -> Iterator[RequestContext]:
    """Nastav request kontext pro blok testu.

    ``secrets``/``config``/``sub``/``email`` zůstávají pozičné kvůli zpětné
    kompatibilitě; nové možnosti (``policy``, ``oauth``, ``request_id``) jsou
    keyword-only. Bez ``policy`` a ``oauth`` se nedalo otestovat ani write
    gating, ani delegovaný OAuth.
    """
    ctx = RequestContext(
        principal=Principal(sub, email),
        secrets=secrets or {},
        config=config or {},
        invalidate_credentials=invalidate_credentials,
        request_id=request_id,
        policy=policy or AccessPolicy(),
        oauth=oauth,
    )
    token = set_context(ctx)
    try:
        yield ctx
    finally:
        try:
            reset_context(token)
        except ValueError:
            # Async test běží ve vlastním kontextu; token z něho se v jiném
            # kontextu resetovat nedá — a netřeba, zaniká s ním.
            pass


__all__ = ["with_context"]
