from types import SimpleNamespace

import pytest

from openmcp_sdk.envelope import ConnectorError
from openmcp_sdk.identity.gateway import GatewayIdentity
from openmcp_sdk.identity.oidc import OidcIdentity
from openmcp_sdk.identity.stdio import StdioIdentity

_INTERNAL_TOKEN = "g" * 32
_USER_ID = "00000000-0000-0000-0000-000000000001"


def test_stdio_local():
    assert StdioIdentity().principal_from_headers({}).sub == "local"


def test_gateway_requires_proof_and_reads_subject():
    identity = GatewayIdentity(_INTERNAL_TOKEN)
    principal = identity.principal_from_headers(
        {
            "X-OpenMCP-Gateway-Token": _INTERNAL_TOKEN,
            "X-OpenMCP-Sub": _USER_ID,
            "X-OpenMCP-Credential-Version": "17",
            "X-OpenMCP-Credential-Owner-Kind": "user",
            "X-OpenMCP-Credential-Owner-Id": _USER_ID,
        }
    )
    assert principal.sub == _USER_ID
    assert principal.credential_version == 17


@pytest.mark.parametrize(
    "headers",
    [
        {"X-OpenMCP-Sub": "u1"},
        {"X-OpenMCP-Gateway-Token": "x" * 32, "X-OpenMCP-Sub": "u1"},
        {"X-OpenMCP-Gateway-Token": _INTERNAL_TOKEN},
    ],
)
def test_gateway_rejects_missing_or_invalid_proof(headers):
    with pytest.raises(ConnectorError):
        GatewayIdentity(_INTERNAL_TOKEN).principal_from_headers(headers)


@pytest.mark.parametrize("version", ["", "0", "-1", "+1", " 1", "1.0", "999999999999"])
def test_gateway_rejects_invalid_credential_version(version):
    with pytest.raises(ConnectorError):
        GatewayIdentity(_INTERNAL_TOKEN).principal_from_headers(
            {
                "X-OpenMCP-Gateway-Token": _INTERNAL_TOKEN,
                "X-OpenMCP-Sub": "u1",
                "X-OpenMCP-Credential-Version": version,
            }
        )


def test_gateway_accepts_team_owner_but_rejects_user_owner_spoof():
    team_id = "00000000-0000-0000-0000-000000000002"
    identity = GatewayIdentity(_INTERNAL_TOKEN)
    team = identity.principal_from_headers(
        {
            "X-OpenMCP-Gateway-Token": _INTERNAL_TOKEN,
            "X-OpenMCP-Sub": _USER_ID,
            "X-OpenMCP-Credential-Version": "4",
            "X-OpenMCP-Credential-Owner-Kind": "team",
            "X-OpenMCP-Credential-Owner-Id": team_id,
        }
    )
    assert team.credential_owner_kind == "team"
    assert team.credential_owner_id == team_id

    with pytest.raises(ConnectorError):
        identity.principal_from_headers(
            {
                "X-OpenMCP-Gateway-Token": _INTERNAL_TOKEN,
                "X-OpenMCP-Sub": _USER_ID,
                "X-OpenMCP-Credential-Version": "4",
                "X-OpenMCP-Credential-Owner-Kind": "user",
                "X-OpenMCP-Credential-Owner-Id": team_id,
            }
        )


def test_gateway_rejects_noncanonical_or_incomplete_credential_binding():
    identity = GatewayIdentity(_INTERNAL_TOKEN)
    base = {
        "X-OpenMCP-Gateway-Token": _INTERNAL_TOKEN,
        "X-OpenMCP-Sub": _USER_ID,
        "X-OpenMCP-Credential-Version": "4",
        "X-OpenMCP-Credential-Owner-Kind": "team",
    }
    with pytest.raises(ConnectorError):
        identity.principal_from_headers(base)
    with pytest.raises(ConnectorError):
        identity.principal_from_headers(
            {
                **base,
                "X-OpenMCP-Credential-Owner-Id": "00000000-0000-0000-0000-00000000000A",
            }
        )


def test_oidc_uses_verified_claims_and_ignores_spoofed_headers(monkeypatch):
    monkeypatch.setattr(
        "openmcp_sdk.identity.oidc.get_access_token",
        lambda: SimpleNamespace(claims={"sub": "verified", "email": "a@b.cz"}),
    )
    identity = OidcIdentity("https://issuer", "https://issuer/jwks", "aud")
    principal = identity.principal_from_headers(
        {"X-OpenMCP-Sub": "attacker", "X-OpenMCP-Email": "evil@example.com"}
    )
    assert principal.sub == "verified"
    assert principal.email == "a@b.cz"


def test_oidc_rejects_request_without_verified_token(monkeypatch):
    monkeypatch.setattr("openmcp_sdk.identity.oidc.get_access_token", lambda: None)
    with pytest.raises(ConnectorError):
        OidcIdentity(
            "https://issuer", "https://issuer/jwks", "aud"
        ).principal_from_headers({"X-OpenMCP-Sub": "spoofed"})


def test_oidc_verifier_factory():
    verifier = OidcIdentity(
        issuer="https://auth.openmcp.cz/realms/openmcp",
        jwks_uri="https://auth.openmcp.cz/realms/openmcp/protocol/openid-connect/certs",
        audience="openmcp-connector",
    ).verifier()
    from fastmcp.server.auth import JWTVerifier

    assert isinstance(verifier, JWTVerifier)
