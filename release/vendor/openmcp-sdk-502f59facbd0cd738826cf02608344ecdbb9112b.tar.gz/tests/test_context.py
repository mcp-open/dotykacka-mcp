import pytest

from openmcp_sdk.context import (
    Principal,
    RequestContext,
    current_context,
    invalidate_current_credentials,
    reset_context,
    set_context,
)
from openmcp_sdk.envelope import ConnectorError, ErrorCode


def test_missing_context_raises():
    with pytest.raises(ConnectorError) as error:
        current_context()
    assert error.value.code == ErrorCode.INTERNAL


def test_context_mappings_are_copied_and_immutable():
    secrets = {"api_key": "k"}
    config = {"region": "cz"}
    ctx = RequestContext(Principal("u1", "a@b.cz"), secrets, config)
    secrets["api_key"] = "changed"
    config["region"] = "sk"
    assert ctx.secrets["api_key"] == "k"
    assert ctx.config["region"] == "cz"
    with pytest.raises(TypeError):
        ctx.config["region"] = "eu"


def test_set_read_invalidate_and_reset():
    calls = []
    ctx = RequestContext(Principal("u1"), {}, {}, lambda: calls.append("invalidated"))
    token = set_context(ctx)
    try:
        assert current_context().principal.sub == "u1"
        assert invalidate_current_credentials() is True
        assert calls == ["invalidated"]
    finally:
        reset_context(token)
    with pytest.raises(ConnectorError):
        current_context()


@pytest.mark.parametrize("sub", ["", "../admin", "a/b", " space", "a\n"])
def test_principal_rejects_unsafe_subjects(sub):
    with pytest.raises(ConnectorError) as error:
        Principal(sub)
    assert error.value.code == ErrorCode.FORBIDDEN
