import pytest

from openmcp_sdk.context import current_context
from openmcp_sdk.envelope import ConnectorError
from openmcp_sdk.identity.stdio import StdioIdentity
from openmcp_sdk.secrets.base import Resolved
from openmcp_sdk.transport.stdio import run_stdio


class Creds:
    def resolve(self, principal):
        return Resolved({"api_key": "k"}, {})

    def invalidate(self, sub):
        pass


class MCP:
    def run(self):
        assert current_context().secrets["api_key"] == "k"


def test_stdio_sets_and_always_resets_context():
    run_stdio(MCP(), StdioIdentity(), Creds())
    with pytest.raises(ConnectorError):
        current_context()


def test_stdio_resets_context_when_server_raises():
    class FailingMCP:
        def run(self):
            raise RuntimeError("boom")

    with pytest.raises(RuntimeError):
        run_stdio(FailingMCP(), StdioIdentity(), Creds())
    with pytest.raises(ConnectorError):
        current_context()
