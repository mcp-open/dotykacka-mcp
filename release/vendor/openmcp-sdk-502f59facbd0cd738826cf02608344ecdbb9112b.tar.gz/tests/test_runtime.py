import pytest

from openmcp_sdk import testing
from openmcp_sdk.context import current_context
from openmcp_sdk.envelope import ConnectorError
from openmcp_sdk.runtime import _parse_allowed_origins, run_connector


def _yaml(tmp_path, *, read_only=True, supports_test=False, sdk_min="0.0.0"):
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: raynet\nname: RAYNET\nversion: 1.0.0\n"
        f"sdk_min_version: {sdk_min}\n"
        "credentials:\n- {key: api_key, secret: true, required: true}\n"
        "operator_config:\n"
        f"- {{key: read_only, type: bool, default: {'true' if read_only else 'false'}}}\n"
        "capabilities:\n"
        f"  supports_test: {'true' if supports_test else 'false'}\n",
        encoding="utf-8",
    )
    return str(path)


class Tool:
    def __init__(self, name, read_only_hint="missing"):
        self.name = name
        if read_only_hint != "missing":
            self.annotations = type(
                "Annotations", (), {"readOnlyHint": read_only_hint}
            )()


class FakeMCP:
    """MCP s libovolnou sadou nástrojů (pro startovací kontroly 0.4)."""

    def __init__(self, tools):
        self._tools = {tool.name: tool for tool in tools}

    def list_tools_sync(self):
        return list(self._tools.values())

    def remove_tool(self, name):
        self._tools.pop(name, None)


class MCP:
    def __init__(self):
        self._tools = {
            "read": Tool("read", True),
            "write": Tool("write", False),
            "ambiguous": Tool("ambiguous", None),
            "missing": Tool("missing"),
        }

    def list_tools_sync(self):
        return list(self._tools.values())

    def remove_tool(self, name):
        self._tools.pop(name, None)


def _local_env(**overrides):
    return {
        "OPENMCP_MODE": "local-stdio",
        "RAYNET_API_KEY": "k",
        **overrides,
    }


def test_readonly_filter_is_fail_closed(tmp_path):
    mcp = MCP()
    run_connector(
        _yaml(tmp_path, read_only=True), mcp, argv_env=_local_env(), serve=False
    )
    assert set(mcp._tools) == {"read"}


def test_runtime_reads_environment_at_call_time(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENMCP_MODE", "local-stdio")
    monkeypatch.setenv("RAYNET_API_KEY", "from-process")
    _, provider, _ = run_connector(_yaml(tmp_path), MCP(), serve=False)
    assert (
        provider.resolve(type("P", (), {"sub": "local"})()).secrets["api_key"]
        == "from-process"
    )


def test_readonly_disabled_keeps_all_tools_and_config_agrees(tmp_path):
    mcp = MCP()
    env = _local_env(RAYNET_READ_ONLY="false")
    _, provider, _ = run_connector(
        _yaml(tmp_path, read_only=True), mcp, argv_env=env, serve=False
    )
    assert set(mcp._tools) == {"read", "write", "ambiguous", "missing"}
    assert (
        provider.resolve(type("P", (), {"sub": "local"})()).config["read_only"] is False
    )


def test_invalid_boolean_override_fails_instead_of_enabling_writes(tmp_path):
    with pytest.raises((RuntimeError, ConnectorError), match="boolean|neplatné"):
        run_connector(
            _yaml(tmp_path),
            MCP(),
            argv_env=_local_env(RAYNET_READ_ONLY="treu"),
            serve=False,
        )


def test_sdk_min_version_too_high_fails(tmp_path):
    with pytest.raises(RuntimeError, match="openmcp_sdk"):
        run_connector(
            _yaml(tmp_path, sdk_min="99.0.0"),
            MCP(),
            argv_env=_local_env(),
            serve=False,
        )


def test_hosted_mode_requires_internal_token(tmp_path):
    with pytest.raises(RuntimeError, match="OPENMCP_INTERNAL_TOKEN"):
        run_connector(
            _yaml(tmp_path),
            MCP(),
            argv_env={"OPENMCP_MODE": "hosted"},
            serve=False,
        )


def test_supports_test_manifest_and_implementation_must_match(tmp_path):
    with pytest.raises(RuntimeError, match="supports_test"):
        run_connector(
            _yaml(tmp_path, supports_test=False),
            MCP(),
            argv_env=_local_env(),
            serve=False,
            test_connection=lambda: "ok",
        )
    with pytest.raises(RuntimeError, match="supports_test"):
        run_connector(
            _yaml(tmp_path, supports_test=True),
            MCP(),
            argv_env=_local_env(),
            serve=False,
        )


def test_supports_test_matching_callback_is_valid(tmp_path):
    _, _, kind = run_connector(
        _yaml(tmp_path, supports_test=True),
        MCP(),
        argv_env=_local_env(),
        serve=False,
        test_connection=lambda: "ok",
    )
    assert kind == "stdio"


def test_with_context_helper_defaults_and_resets():
    with testing.with_context(config={"region": "cz"}):
        assert current_context().config["region"] == "cz"
    with pytest.raises(ConnectorError):
        current_context()


def test_allowed_origins_are_normalized_and_validated():
    assert _parse_allowed_origins(" https://claude.ai/,https://claude.com ") == [
        "https://claude.ai",
        "https://claude.com",
    ]
    with pytest.raises(RuntimeError):
        _parse_allowed_origins("https://user:pass@example.com/path")


@pytest.mark.anyio
async def test_tool_enumeration_works_inside_running_event_loop(tmp_path):
    class AsyncOnly:
        def __init__(self):
            self._tools = {"read": Tool("read", True), "write": Tool("write", False)}

        async def get_tools(self):
            return self._tools

        def remove_tool(self, name):
            self._tools.pop(name, None)

    async_mcp = AsyncOnly()
    run_connector(_yaml(tmp_path), async_mcp, argv_env=_local_env(), serve=False)
    assert set(async_mcp._tools) == {"read"}


# -- automatizace v run_connector (0.4) ---------------------------------------


def test_pii_salt_without_policy_is_refused(tmp_path):
    """Salt bez politiky je zbytečný k8s secret — ať to řekne start."""
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: raynet\nname: R\nversion: 1.0.0\nsdk_min_version: 0.4.0\n"
        "runtime:\n  pii_salt: true\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="pii_salt"):
        run_connector(str(path), FakeMCP([]), argv_env={}, serve=False)


def test_policy_without_pii_salt_is_refused(tmp_path):
    """A politika bez saltu je konektor, který spadne při prvním requestu."""
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: raynet\nname: R\nversion: 1.0.0\nsdk_min_version: 0.4.0\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="pii_salt"):
        run_connector(
            str(path), FakeMCP([]), argv_env={}, serve=False, pii=object()
        )


def test_pii_salt_is_required_at_startup(tmp_path):
    """Fail-closed: chybějící salt se jinak projeví až po restartu podu."""
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: raynet\nname: R\nversion: 1.0.0\nsdk_min_version: 0.4.0\n"
        "runtime:\n  pii_salt: true\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="OPENMCP_PII_SALT"):
        run_connector(
            str(path), FakeMCP([]), argv_env={}, serve=False, pii=object()
        )


def test_run_result_still_unpacks_as_triple(tmp_path):
    """Zpětná kompatibilita: `a, b, c = run_connector(...)` musí fungovat."""
    identity, creds, transport = run_connector(
        _yaml(tmp_path), FakeMCP([Tool("read", True)]),
        argv_env={"RAYNET_API_KEY": "k"}, serve=False,
    )
    assert transport == "stdio"
    assert identity is not None and creds is not None


def test_display_tools_mismatch_is_fatal_from_0_4(tmp_path):
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: raynet\nname: R\nversion: 1.0.0\nsdk_min_version: 0.4.0\n"
        "display:\n  tools:\n    - {name: chybajuci, description: x}\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="display.tools"):
        run_connector(str(path), FakeMCP([Tool("iny", True)]), argv_env={}, serve=False)


def test_display_tools_mismatch_only_warns_below_0_4(tmp_path, caplog):
    """Konektory se dají překlápět po jednom — manifest nese přepínač."""
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: raynet\nname: R\nversion: 1.0.0\nsdk_min_version: 0.3.0\n"
        "display:\n  tools:\n    - {name: chybajuci, description: x}\n",
        encoding="utf-8",
    )
    # OPENMCP_LOG_SETUP=false: `log_setup()` jinak vyčistí root handlery
    # a caplog by neměl co zachytit.
    with caplog.at_level("WARNING"):
        run_connector(
            str(path),
            FakeMCP([Tool("iny", True)]),
            argv_env={"OPENMCP_LOG_SETUP": "false"},
            serve=False,
        )
    assert "display.tools" in caplog.text


def test_missing_read_only_hint_is_fatal_from_0_4(tmp_path):
    """Bez anotace nástroj v read-only režimu tiše zmizí."""
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: raynet\nname: R\nversion: 1.0.0\nsdk_min_version: 0.4.0\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="readOnlyHint"):
        run_connector(str(path), FakeMCP([Tool("nic")]), argv_env={}, serve=False)


def test_supports_write_false_with_mutating_tool_is_fatal(tmp_path):
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: raynet\nname: R\nversion: 1.0.0\nsdk_min_version: 0.4.0\n"
        "capabilities: {supports_write: false}\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="supports_write"):
        run_connector(str(path), FakeMCP([Tool("zapis", False)]), argv_env={}, serve=False)


def test_supports_write_true_without_mutating_tool_is_fatal(tmp_path):
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: raynet\nname: R\nversion: 1.0.0\nsdk_min_version: 0.4.0\n"
        "capabilities: {supports_write: true, default_read_only: false}\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="supports_write"):
        run_connector(str(path), FakeMCP([Tool("citanie", True)]), argv_env={}, serve=False)


def test_logging_setup_can_be_disabled(tmp_path, monkeypatch):
    calls = []
    import openmcp_sdk.runtime as runtime_mod

    monkeypatch.setattr(runtime_mod, "log_setup", lambda **kw: calls.append(kw))
    run_connector(
        _yaml(tmp_path), FakeMCP([Tool("read", True)]),
        argv_env={"RAYNET_API_KEY": "k", "OPENMCP_LOG_SETUP": "false"}, serve=False,
    )
    assert calls == []


def test_logging_setup_runs_by_default_with_slug_component(tmp_path, monkeypatch):
    calls = []
    import openmcp_sdk.runtime as runtime_mod

    monkeypatch.setattr(runtime_mod, "log_setup", lambda **kw: calls.append(kw))
    run_connector(
        _yaml(tmp_path), FakeMCP([Tool("read", True)]),
        argv_env={"RAYNET_API_KEY": "k"}, serve=False,
    )
    assert calls == [{"level": "INFO", "component": "raynet"}]


def test_pii_mismatch_only_warns_below_0_4(tmp_path, caplog):
    """Regrese: bump SDK nesmí shodit start nemigrovaného konektoru.

    Dotykačka má `runtime.pii_salt: true`, ale její `__main__.py` parametr
    `pii=` ještě nezná. S tvrdou kontrolou se konektor přestal spouštět — a
    jejích 31 testů to nezachytilo, protože žádný `run_connector` nevolá.
    """
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: dotykacka\nname: D\nversion: 1.0.0\nsdk_min_version: 0.3.0\n"
        "runtime:\n  pii_salt: true\n",
        encoding="utf-8",
    )
    with caplog.at_level("WARNING"):
        run_connector(
            str(path),
            FakeMCP([]),
            argv_env={"OPENMCP_PII_SALT": "x", "OPENMCP_LOG_SETUP": "false"},
            serve=False,
        )
    assert "pii_salt" in caplog.text


def test_empty_log_setup_env_is_treated_as_unset(tmp_path):
    """`env: [{name: X, value: ""}]` je v k8s běžný způsob „nenastavit"."""
    run_connector(
        _yaml(tmp_path),
        FakeMCP([Tool("read", True)]),
        argv_env=_local_env(OPENMCP_LOG_SETUP=""),
        serve=False,
    )


def test_prerelease_sdk_min_version_still_strict(tmp_path):
    """`0.4.0rc1` se hlásí k přísné verzi — nesmí propadnout do varování."""
    path = tmp_path / "connector.yaml"
    path.write_text(
        "slug: demo\nname: D\nversion: 1.0.0\nsdk_min_version: 0.4.0rc1\n"
        "display:\n  tools:\n    - {name: chybajuci, description: x}\n",
        encoding="utf-8",
    )
    with pytest.raises(RuntimeError, match="display.tools"):
        run_connector(str(path), FakeMCP([Tool("iny", True)]), argv_env={}, serve=False)
