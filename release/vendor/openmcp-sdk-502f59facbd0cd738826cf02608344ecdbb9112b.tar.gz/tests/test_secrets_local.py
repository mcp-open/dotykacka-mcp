import pytest

from openmcp_sdk.context import Principal
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.manifest import Manifest
from openmcp_sdk.secrets.env import EnvProvider
from openmcp_sdk.secrets.userfile import UserFileProvider


def _manifest():
    return Manifest.model_validate(
        {
            "slug": "raynet",
            "name": "RAYNET",
            "version": "1.0.0",
            "credentials": [
                {"key": "api_key", "secret": True, "required": True},
                {"key": "instance", "required": True},
            ],
            "user_config": [
                {
                    "key": "region",
                    "type": "enum",
                    "choices": ["cz", "sk"],
                    "default": "cz",
                },
                {"key": "limit", "type": "int", "default": 20},
            ],
            "operator_config": [
                {"key": "read_only", "type": "bool", "default": True},
            ],
        }
    )


def test_env_provider_uses_injected_environment_and_coerces_types():
    provider = EnvProvider(
        _manifest(),
        {
            "RAYNET_API_KEY": "k",
            "RAYNET_INSTANCE": "demo",
            "RAYNET_REGION": "sk",
            "RAYNET_LIMIT": "50",
            "RAYNET_READ_ONLY": "false",
        },
    )
    resolved = provider.resolve(Principal("local"))
    assert resolved.secrets == {"api_key": "k"}
    assert resolved.config == {
        "read_only": False,
        "instance": "demo",
        "region": "sk",
        "limit": 50,
    }
    with pytest.raises(TypeError):
        resolved.config["region"] = "cz"


def test_env_provider_missing_required_raises():
    with pytest.raises(ConnectorError) as error:
        EnvProvider(_manifest(), {}).resolve(Principal("local"))
    assert error.value.code == ErrorCode.INVALID_INPUT


def test_userfile_provider_validates_shape_and_values(tmp_path):
    path = tmp_path / "users.json"
    path.write_text(
        '{"a@b.cz": {"api_key": "k", "instance": "demo", "region": "sk", "limit": 7}}',
        encoding="utf-8",
    )
    resolved = UserFileProvider(_manifest(), str(path)).resolve(
        Principal("u1", "a@b.cz")
    )
    assert resolved.secrets == {"api_key": "k"}
    assert resolved.config["limit"] == 7


def test_userfile_provider_missing_user_is_forbidden(tmp_path):
    path = tmp_path / "users.json"
    path.write_text("{}", encoding="utf-8")
    with pytest.raises(ConnectorError) as error:
        UserFileProvider(_manifest(), str(path)).resolve(Principal("u1", "nobody@b.cz"))
    assert error.value.code == ErrorCode.FORBIDDEN
