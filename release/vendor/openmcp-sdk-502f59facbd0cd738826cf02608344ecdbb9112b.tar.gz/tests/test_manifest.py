import textwrap

import pytest

from openmcp_sdk.manifest import Field, load_manifest


def _write(tmp_path, value):
    path = tmp_path / "connector.yaml"
    path.write_text(textwrap.dedent(value), encoding="utf-8")
    return str(path)


def test_loads_strict_typed_manifest(tmp_path):
    path = _write(
        tmp_path,
        """
        slug: raynet
        name: RAYNET
        version: 1.0.0
        credentials:
          - {key: api_key, secret: true, required: true}
          - {key: instance, required: true}
        user_config:
          - {key: region, type: enum, choices: [cz, sk], default: cz}
        operator_config:
          - {key: read_only, type: bool, default: true}
        egress:
          host: app.raynet.cz
          path_prefix: /api/v2/
          methods: [get]
        """,
    )
    manifest = load_manifest(path)
    assert manifest.env_names()["api_key"] == "RAYNET_API_KEY"
    assert manifest.operator_env_names()["read_only"] == "RAYNET_READ_ONLY"
    assert manifest.egress.path_prefix == "/api/v2"
    assert manifest.egress.methods == ["GET"]


@pytest.mark.parametrize(
    "body",
    [
        "slug: demo\nname: X\nversion: 1.0.0\nunknown: true\n",
        "slug: Bad_Slug\nname: X\nversion: 1.0.0\n",
        "slug: demo\nname: X\nversion: nonsense\n",
        "slug: demo\nname: X\nversion: 1.0.0\ncredentials:\n- {key: api_key, secret: true, default: checked-in}\n",
        "slug: demo\nname: X\nversion: 1.0.0\nuser_config:\n- {key: region, type: enum, choices: []}\n",
        "slug: demo\nname: X\nversion: 1.0.0\ncredentials:\n- {key: same}\nuser_config:\n- {key: same}\n",
    ],
)
def test_rejects_invalid_or_ambiguous_manifest(tmp_path, body):
    with pytest.raises(ValueError):
        load_manifest(_write(tmp_path, body))


def test_runtime_block_parses_and_keeps_unset_as_none(tmp_path):
    """`runtime:` musí projít a nezadaná pole zůstat None/"".

    Regrese: dotykacka-mcp měla tento blok v manifestu, ale `Manifest` ho
    neznal a `extra="forbid"` shodil start konektoru. Defaulty se tu
    ZÁMĚRNĚ nedoplňují — renderer (Go) má vlastní a musí zůstat jeho.
    """
    manifest = load_manifest(
        _write(
            tmp_path,
            """
            slug: dotykacka
            name: Dotykacka
            version: 0.1.0
            runtime:
              pii_salt: true
              health_path: /healthz
              vault_ttl: 5
            """,
        )
    )
    assert manifest.runtime.pii_salt is True
    assert manifest.runtime.health_path == "/healthz"
    assert manifest.runtime.vault_ttl == 5
    assert manifest.runtime.replicas is None


def test_runtime_defaults_when_block_absent(tmp_path):
    manifest = load_manifest(
        _write(tmp_path, "slug: demo\nname: X\nversion: 1.0.0\n")
    )
    assert manifest.runtime.pii_salt is False
    assert manifest.runtime.health_path == ""
    assert manifest.runtime.vault_ttl is None
    assert manifest.runtime.replicas is None


@pytest.mark.parametrize(
    "body",
    [
        # cesta, kterou SDK neservíruje → httpGet probe by nikdy neprošla
        "slug: demo\nname: X\nversion: 1.0.0\nruntime:\n  health_path: /health\n",
        "slug: demo\nname: X\nversion: 1.0.0\nruntime:\n  health_path: relativna\n",
        "slug: demo\nname: X\nversion: 1.0.0\nruntime:\n  replicas: -1\n",
        "slug: demo\nname: X\nversion: 1.0.0\nruntime:\n  vault_ttl: -5\n",
        "slug: demo\nname: X\nversion: 1.0.0\nruntime:\n  nieco: 1\n",
    ],
)
def test_rejects_invalid_runtime(tmp_path, body):
    with pytest.raises(ValueError):
        load_manifest(_write(tmp_path, body))


def test_health_path_matches_served_routes():
    """Validátor manifestu a HTTP transport musí číst ten samý seznam."""
    from openmcp_sdk.manifest import SERVED_HEALTH_PATHS

    assert "/healthz" in SERVED_HEALTH_PATHS


@pytest.mark.parametrize(
    "body",
    [
        # supports_write=false + default_read_only=false si odporují
        "slug: demo\nname: X\nversion: 1.0.0\n"
        "capabilities: {supports_write: false, default_read_only: false}\n",
        # mrtvý přepínač v UI
        "slug: demo\nname: X\nversion: 1.0.0\n"
        "capabilities: {supports_write: false}\n"
        "operator_config:\n- {key: require_write_confirmation, type: bool, default: true}\n",
    ],
)
def test_rejects_contradictory_write_capability(tmp_path, body):
    with pytest.raises(ValueError):
        load_manifest(_write(tmp_path, body))


def test_read_only_connector_may_use_post_upstream(tmp_path):
    """`supports_write` je o cizích datech, ne o HTTP metodě upstreamu.

    ares má `[GET, POST]` a `supports_write: false` — POST používá pro
    vyhledávání. Omezit metody podle supports_write by ho rozbilo.
    """
    manifest = load_manifest(
        _write(
            tmp_path,
            """
            slug: ares
            name: ARES
            version: 0.2.1
            capabilities: {supports_write: false}
            egress:
              host: ares.gov.cz
              methods: [GET, POST]
            """,
        )
    )
    assert manifest.egress.methods == ["GET", "POST"]


def test_empty_egress_is_none(tmp_path):
    manifest = load_manifest(
        _write(tmp_path, "slug: template\nname: Template\nversion: 0.1.0\negress: {}\n")
    )
    assert manifest.egress is None


@pytest.mark.parametrize(
    ("field", "raw", "expected"),
    [
        (Field(key="enabled", type="bool"), "false", False),
        (Field(key="enabled", type="bool"), "YES", True),
        (Field(key="limit", type="int"), "42", 42),
        (Field(key="region", type="enum", choices=["cz", "sk"]), "sk", "sk"),
    ],
)
def test_field_coercion_is_strict(field, raw, expected):
    assert field.parse(raw) == expected


@pytest.mark.parametrize(
    ("field", "raw"),
    [
        (Field(key="enabled", type="bool"), "treu"),
        (Field(key="limit", type="int"), True),
        (Field(key="region", type="enum", choices=["cz", "sk"]), "eu"),
    ],
)
def test_field_coercion_rejects_invalid_values(field, raw):
    with pytest.raises(ValueError):
        field.parse(raw)


def test_directory_field_supports_native_picker_multiple_values():
    field = Field(
        key="allowed_directories",
        type="directory",
        required=True,
        multiple=True,
    )

    assert field.parse([" /tmp/a ", "/tmp/b"]) == ["/tmp/a", "/tmp/b"]


@pytest.mark.parametrize(
    "kwargs",
    [
        {"key": "region", "type": "string", "multiple": True},
        {"key": "roots", "type": "directory", "multiple": True, "default": []},
        {"key": "file", "type": "file", "default": ""},
    ],
)
def test_directory_and_file_field_reject_invalid_definition(kwargs):
    with pytest.raises(ValueError):
        Field(**kwargs)


_OAUTH_MANIFEST = """
    slug: dotykacka
    name: Dotykačka
    version: 0.1.0
    sdk_min_version: 0.3.0
    auth:
      type: oauth_delegated
      provider: dotykacka
      operator_fields:
        - {key: client_id, label: Client ID, type: string, required: true}
        - {key: client_secret, label: Client Secret, secret: true, required: true}
      runtime_secrets: [refresh_token, cloud_id]
"""


def test_oauth_delegated_manifest_is_valid(tmp_path):
    manifest = load_manifest(_write(tmp_path, _OAUTH_MANIFEST))
    assert manifest.auth.type == "oauth_delegated"
    assert manifest.auth.provider == "dotykacka"
    assert manifest.auth.runtime_secrets == ["refresh_token", "cloud_id"]
    assert {f.key for f in manifest.auth.operator_fields} == {
        "client_id",
        "client_secret",
    }
    assert manifest.runtime_secret_env_names() == {
        "refresh_token": "DOTYKACKA_REFRESH_TOKEN",
        "cloud_id": "DOTYKACKA_CLOUD_ID",
    }


def test_default_auth_is_credentials(tmp_path):
    manifest = load_manifest(
        _write(tmp_path, "slug: demo\nname: X\nversion: 1.0.0\n")
    )
    assert manifest.auth.type == "credentials"
    assert manifest.auth.provider is None
    assert manifest.auth.runtime_secrets == []


@pytest.mark.parametrize(
    "body",
    [
        # oauth_delegated nesmí deklarovat credentials[]
        _OAUTH_MANIFEST + "    credentials:\n      - {key: api_key, secret: true}\n",
        # provider je povinný
        "slug: demo\nname: X\nversion: 1.0.0\n"
        "auth:\n  type: oauth_delegated\n"
        "  operator_fields:\n"
        "    - {key: client_id}\n"
        "    - {key: client_secret, secret: true}\n"
        "  runtime_secrets: [refresh_token]\n",
        # operator_fields chybí client_secret
        "slug: demo\nname: X\nversion: 1.0.0\n"
        "auth:\n  type: oauth_delegated\n  provider: dotykacka\n"
        "  operator_fields:\n    - {key: client_id}\n"
        "  runtime_secrets: [refresh_token]\n",
        # client_secret musí mít secret=true
        "slug: demo\nname: X\nversion: 1.0.0\n"
        "auth:\n  type: oauth_delegated\n  provider: dotykacka\n"
        "  operator_fields:\n"
        "    - {key: client_id}\n"
        "    - {key: client_secret}\n"
        "  runtime_secrets: [refresh_token]\n",
        # runtime_secrets nesmí být prázdné
        "slug: demo\nname: X\nversion: 1.0.0\n"
        "auth:\n  type: oauth_delegated\n  provider: dotykacka\n"
        "  operator_fields:\n"
        "    - {key: client_id}\n"
        "    - {key: client_secret, secret: true}\n",
        # auth typu credentials nesmí obsahovat provider/operator_fields
        "slug: demo\nname: X\nversion: 1.0.0\n"
        "auth:\n  type: credentials\n  provider: dotykacka\n",
    ],
)
def test_rejects_invalid_oauth_delegated_manifest(tmp_path, body):
    with pytest.raises(ValueError):
        load_manifest(_write(tmp_path, body))
