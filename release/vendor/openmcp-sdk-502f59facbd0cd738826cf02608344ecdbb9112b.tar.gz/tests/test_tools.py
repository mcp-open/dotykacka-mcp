import pytest
from fastmcp import FastMCP

from openmcp_sdk.tools import tool


def _tools(mcp: FastMCP) -> dict:
    from openmcp_sdk.runtime import _enumerate_tools

    return {tool.name: tool for tool in _enumerate_tools(mcp)}


def test_decorated_function_stays_callable():
    """Kvůli tomuto dekorátor existuje: unit test musí umět funkci zavolat."""
    mcp = FastMCP("t")

    @tool(mcp, read_only=True)
    def ping(value: int) -> int:
        """Vrátí dvojnásobek."""
        return value * 2

    assert ping(21) == 42
    assert ping.__doc__ == "Vrátí dvojnásobek."
    assert ping.__name__ == "ping"


def test_tool_is_registered_with_read_only_annotation():
    mcp = FastMCP("t")

    @tool(mcp, read_only=True)
    def ping() -> str:
        return "pong"

    registered = _tools(mcp)["ping"]
    assert registered.annotations.readOnlyHint is True
    assert registered.annotations.destructiveHint is False


def test_write_tool_annotations():
    mcp = FastMCP("t")

    @tool(mcp, read_only=False, destructive=True)
    def update_thing() -> str:
        return "ok"

    registered = _tools(mcp)["update_thing"]
    assert registered.annotations.readOnlyHint is False
    assert registered.annotations.destructiveHint is True


def test_create_tool_is_not_destructive():
    """Založení záznamu není přepis — `destructiveHint` je odlišuje."""
    mcp = FastMCP("t")

    @tool(mcp, read_only=False, destructive=False)
    def create_thing() -> str:
        return "ok"

    registered = _tools(mcp)["create_thing"]
    assert registered.annotations.readOnlyHint is False
    assert registered.annotations.destructiveHint is False


def test_read_only_is_required_keyword():
    """Nástroj se nesmí dát zaregistrovat bez rozhodnutí o anotaci.

    Bez ní ho read-only filtr při startu fail-closed odregistruje a vypadá
    to, jako by se nástroj „ztratil".
    """
    mcp = FastMCP("t")
    with pytest.raises(TypeError):
        tool(mcp)  # type: ignore[call-arg]


@pytest.mark.parametrize("bad", [None, 1, "true"])
def test_read_only_must_be_bool(bad):
    mcp = FastMCP("t")
    with pytest.raises(TypeError):
        tool(mcp, read_only=bad)


def test_read_only_and_destructive_are_contradictory():
    mcp = FastMCP("t")
    with pytest.raises(ValueError):
        tool(mcp, read_only=True, destructive=True)


def test_explicit_name_overrides_function_name():
    mcp = FastMCP("t")

    @tool(mcp, read_only=True, name="ares_subjekt_lookup")
    def lookup_subjekt() -> str:
        return "ok"

    names = set(_tools(mcp))
    assert "ares_subjekt_lookup" in names
    assert "lookup_subjekt" not in names
    # Business funkce zůstává volatelná pod svým jménem — bez wrapperu.
    assert lookup_subjekt() == "ok"


def test_docstring_becomes_description():
    mcp = FastMCP("t")

    @tool(mcp, read_only=True)
    def ping() -> str:
        """Ověří spojení."""
        return "pong"

    assert "Ověří spojení." in (_tools(mcp)["ping"].description or "")
