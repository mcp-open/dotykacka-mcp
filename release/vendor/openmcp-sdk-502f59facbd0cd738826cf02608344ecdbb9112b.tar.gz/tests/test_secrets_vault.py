import pytest

from openmcp_sdk.context import Principal
from openmcp_sdk.envelope import ConnectorError, ErrorCode
from openmcp_sdk.manifest import Manifest
import asyncio

from openmcp_sdk.secrets.vault import AsyncVaultProvider, VaultProvider

_USER_ID = "00000000-0000-0000-0000-000000000001"


def _principal(version: int) -> Principal:
    return Principal(
        _USER_ID,
        credential_version=version,
        credential_owner_kind="user",
        credential_owner_id=_USER_ID,
    )


def _manifest():
    return Manifest.model_validate(
        {
            "slug": "raynet",
            "name": "RAYNET",
            "version": "1.0.0",
            "credentials": [
                {"key": "api_key", "secret": True, "required": True},
                {"key": "instance", "required": True},
            ],
            "operator_config": [
                {"key": "redact_pii", "type": "bool", "default": True},
            ],
        }
    )


def test_vault_split_cache_invalidate_and_operator_override():
    reads = []

    def read_fn(path, version):
        reads.append((path, version))
        return {"api_key": "k", "instance": "demo"}

    provider = VaultProvider(
        _manifest(),
        addr="http://vault",
        role="raynet",
        read_fn=read_fn,
        environ={"RAYNET_REDACT_PII": "false"},
    )
    resolved = provider.resolve(_principal(7))
    assert resolved.secrets == {"api_key": "k"}
    assert resolved.config == {"redact_pii": False, "instance": "demo"}
    provider.resolve(_principal(7))
    assert reads == [(f"users/{_USER_ID}/raynet", 7)]
    provider.invalidate(_USER_ID)
    provider.resolve(_principal(7))
    assert len(reads) == 2


def test_vault_never_reads_latest_and_cache_is_version_scoped():
    reads = []

    def read_fn(path, version):
        reads.append((path, version))
        return {"api_key": f"k-{version}", "instance": "demo"}

    provider = VaultProvider(
        _manifest(), addr="http://vault", role="raynet", read_fn=read_fn
    )
    with pytest.raises(ConnectorError) as missing:
        provider.resolve(Principal(_USER_ID))
    assert missing.value.code == ErrorCode.FORBIDDEN
    assert reads == []

    first = provider.resolve(_principal(3))
    second = provider.resolve(_principal(4))
    assert first.secrets["api_key"] == "k-3"
    assert second.secrets["api_key"] == "k-4"
    assert reads == [
        (f"users/{_USER_ID}/raynet", 3),
        (f"users/{_USER_ID}/raynet", 4),
    ]


def test_vault_team_owner_uses_team_path_and_is_cache_isolated_from_user():
    team_id = "00000000-0000-0000-0000-000000000002"
    reads = []

    def read_fn(path, version):
        reads.append((path, version))
        return {"api_key": path, "instance": "demo"}

    provider = VaultProvider(
        _manifest(), addr="http://vault", role="raynet", read_fn=read_fn
    )
    user = _principal(8)
    team = Principal(
        _USER_ID,
        credential_version=8,
        credential_owner_kind="team",
        credential_owner_id=team_id,
    )

    user_result = provider.resolve(user)
    team_result = provider.resolve(team)
    assert user_result.secrets["api_key"] == f"users/{_USER_ID}/raynet"
    assert team_result.secrets["api_key"] == f"teams/{team_id}/raynet"
    assert reads == [
        (f"users/{_USER_ID}/raynet", 8),
        (f"teams/{team_id}/raynet", 8),
    ]

    provider.invalidate_principal(team)
    provider.resolve(user)
    provider.resolve(team)
    assert reads[-1] == (f"teams/{team_id}/raynet", 8)
    assert len(reads) == 3


def test_vault_does_not_expose_backend_exception():
    def fail(path, version):
        raise RuntimeError(f"token=secret at {path}")

    provider = VaultProvider(
        _manifest(), addr="http://vault", role="raynet", read_fn=fail
    )
    with pytest.raises(ConnectorError) as error:
        provider.resolve(_principal(1))
    assert error.value.code == ErrorCode.UPSTREAM_UNAVAILABLE
    assert "secret" not in error.value.message


def test_vault_retries_transient_failure_and_async_facade():
    calls = 0

    def read_fn(path, version):
        nonlocal calls
        calls += 1
        if calls == 1:
            raise RuntimeError("temporary")
        return {"api_key": "k", "instance": "demo"}

    provider = VaultProvider(
        _manifest(),
        addr="http://vault",
        role="raynet",
        read_fn=read_fn,
        max_retries=1,
        retry_backoff=0,
    )
    resolved = asyncio.run(
        AsyncVaultProvider(provider).resolve(_principal(1))
    )
    assert resolved.secrets["api_key"] == "k"
    assert calls == 2


def test_vault_client_always_verifies_tls_and_supports_private_ca(tmp_path):
    default = VaultProvider(_manifest(), addr="https://vault", role="raynet")
    assert default._client_kwargs()["verify"] is True

    ca_cert = tmp_path / "vault-ca.crt"
    ca_cert.write_text("test-ca", encoding="utf-8")
    private = VaultProvider(
        _manifest(),
        addr="https://vault",
        role="raynet",
        ca_cert=str(ca_cert),
    )
    assert private._client_kwargs(token="short-lived") == {
        "url": "https://vault",
        "timeout": 10.0,
        "verify": str(ca_cert),
        "token": "short-lived",
    }


@pytest.mark.parametrize(
    "addr",
    [
        "vault:8200",
        "ftp://vault:8200",
        "https://user:pass@vault:8200",
        "https://vault:8200/v1/sys/health",
        "https://vault:8200?token=x",
        "https://vault:8200#fragment",
        " https://vault:8200",
        "https://vault:invalid",
    ],
)
def test_vault_rejects_non_origin_or_ambiguous_addresses(addr):
    with pytest.raises(ValueError, match="Vault addr"):
        VaultProvider(_manifest(), addr=addr, role="raynet")


def test_vault_https_cutover_flag_is_fail_closed(tmp_path):
    with pytest.raises(ValueError, match="VAULT_REQUIRE_HTTPS"):
        VaultProvider(
            _manifest(),
            addr="http://vault.openmcp-system.svc.cluster.local:8200",
            role="raynet",
            require_https=True,
        )

    with pytest.raises(ValueError, match="CA certifikát"):
        VaultProvider(
            _manifest(),
            addr="https://vault.openmcp-system.svc.cluster.local:8200",
            role="raynet",
            require_https=True,
        )

    ca_cert = tmp_path / "vault-ca.crt"
    ca_cert.write_text("test-ca", encoding="utf-8")
    provider = VaultProvider(
        _manifest(),
        addr="https://vault.openmcp-system.svc.cluster.local:8200",
        role="raynet",
        require_https=True,
        ca_cert=str(ca_cert),
    )
    assert provider._client_kwargs()["verify"] == str(ca_cert)


def test_vault_rejects_missing_relative_or_http_ca_path(tmp_path):
    ca_cert = tmp_path / "vault-ca.crt"
    ca_cert.write_text("test-ca", encoding="utf-8")
    for addr, path in (
        ("https://vault", "relative/ca.crt"),
        ("https://vault", str(tmp_path / "missing.crt")),
        ("http://vault", str(ca_cert)),
    ):
        with pytest.raises(ValueError, match="CA certifikát"):
            VaultProvider(_manifest(), addr=addr, role="raynet", ca_cert=path)
