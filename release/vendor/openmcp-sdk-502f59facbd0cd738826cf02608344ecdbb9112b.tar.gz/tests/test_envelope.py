import json

import pytest
from pydantic import ValidationError

from openmcp_sdk.envelope import ConnectorError, ErrorCode, Provenance, now_utc_iso


def test_connector_error_is_bounded_single_line_json():
    error = ConnectorError(ErrorCode.FORBIDDEN, "bad\nmessage")
    assert json.loads(str(error)) == {
        "error": {"code": "forbidden", "message": "bad message"}
    }


def test_provenance_validates_url_timestamp_and_extras():
    value = Provenance(
        source_id="ares",
        source_url="https://ares.gov.cz/api",
        retrieved_at=now_utc_iso(),
    )
    assert value.freshness == "live"
    with pytest.raises(ValidationError):
        Provenance(
            source_id="ARES/unsafe",
            source_url="not-a-url",
            retrieved_at="2026-07-20",
            extra="ignored-no-more",
        )
