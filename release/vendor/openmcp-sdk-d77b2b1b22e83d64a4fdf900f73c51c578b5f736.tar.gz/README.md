# openmcp_sdk

Sdílený Python runtime a kontrakt pro OpenMCP FastMCP konektory. SDK sjednocuje
manifest, identitu, credentials, request context, transporty, typované chyby a
provenance. Verze 0.2 je bezpečnostně zpřísněný kontrakt pro hosted i
self-hosted provoz.

## Výstup nástroje

Každý nástroj vrací konkrétní Pydantic model odvozený z `EnvelopeBase`:

```json
{
  "data": {"connector-specific": true},
  "provenance": {
    "source_id": "ares",
    "source_url": "https://ares.gov.cz/...",
    "retrieved_at": "2026-07-20T12:34:56Z",
    "freshness": "live"
  },
  "warnings": []
}
```

`Provenance` validuje HTTP(S) URL, bezpečný `source_id` a UTC timestamp s
koncovkou `Z`. Veřejné chyby používají `ConnectorError` a uzavřenou množinu
kódů:

- `invalid_input`
- `upstream_unavailable`
- `upstream_error`
- `rate_limited`
- `forbidden`
- `internal`

Pro upstream HTTP volání používejte `openmcp_sdk.raise_for_status()` a
`map_http_exc()`. Upstream 401 invaliduje cache credentials přímo v aktivním
request contextu; surový text výjimky se klientovi nevrací.

## Request context

Tool čte identitu a konfiguraci pouze přes:

```python
from openmcp_sdk import current_context

ctx = current_context()
api_key = ctx.secrets["api_key"]
region = ctx.config["region"]
subject = ctx.principal.sub
```

`secrets` a `config` jsou per-request kopie bez možnosti mutace. HTTP transport
kontext vždy resetuje; totéž platí po ukončení nebo pádu stdio serveru.

## Režimy

`run_connector("connector.yaml", mcp)` vybírá režim přes `OPENMCP_MODE`.

### `local-stdio`

Identita je `sub=local`; credentials a user config se čtou z
`<SLUG>_<KEY>` env proměnných. Hodnoty se podle manifestu striktně převádějí na
`string`, `int`, `bool` nebo `enum`.

Tento režim nevyžaduje žádný OpenMCP účet ani běžící OpenMCP služby. Je určen
pro lokální používání, vývoj a MCP klienty, které spouštějí proces přes stdio.
Stačí nainstalovat konektor, nastavit env proměnné a spustit jeho Python modul:

```bash
cd konektor
cp .env.example .env                 # pokud konektor soubor poskytuje
set -a; . ./.env; set +a
export OPENMCP_MODE=local-stdio      # je to i výchozí hodnota
python -m connector
```

Místo načítání `.env` lze proměnné zadat přímo:

```bash
OPENMCP_MODE=local-stdio \
  MYCONNECTOR_API_KEY='tajny-api-kluc' \
  MYCONNECTOR_REGION=eu \
  python -m connector
```

Přesný seznam proměnných určuje `connector.yaml`. Pro každé pole `credentials`
a `user_config` platí název `<SLUG>_<KEY>` převedený na velká písmena:

| Manifest field | Environment variable |
|---|---|
| `api_key` | `<SLUG>_API_KEY` |
| `region` | `<SLUG>_REGION` |
| `read_only` v `operator_config` | `<SLUG>_READ_ONLY` |

Typy se validují striktně. Booleany přijímají pouze `true`, `false`, `1`, `0`,
`yes`, `no`, `on` nebo `off`; neplatná hodnota zastaví start. Povinný secret
bez env hodnoty je chyba. Secret hodnoty se nevypisují do logu.

Lokální stdio server je jednouživatelský (`sub=local`). Pokud je potřeba více
uživatelů, per-user credentials nebo HTTP endpoint, použijte režim `hosted`
nebo `self-hosted`.

### Lokální MCP klient

Proces lze připojit přímo v konfiguraci klienta bez OpenMCP gatewaye. Např.
Claude Desktop/Claude Code spustí nový proces a env proměnné mu předá:

```json
{
  "mcpServers": {
    "my-connector": {
      "command": "python",
      "args": ["-m", "connector"],
      "cwd": "/absolute/path/to/your-connector",
      "env": {
        "OPENMCP_MODE": "local-stdio",
        "MYCONNECTOR_API_KEY": "...",
        "MYCONNECTOR_REGION": "eu"
      }
    }
  }
}
```

Při chybě `chybějící credentials` zkontrolujte název podle manifestu, aktuální
pracovní adresář (`connector.yaml`) a to, že proměnné byly nastaveny v procesu,
který spouští MCP klient. OpenMCP proměnné jako `VAULT_ADDR`, `OIDC_ISSUER` a
`OPENMCP_INTERNAL_TOKEN` jsou potřeba jen pro vzdálené režimy.

### `hosted`

Gateway posílá `X-OpenMCP-Sub` a `X-OpenMCP-Gateway-Token`. Connector vyžaduje
`VAULT_ADDR` a `OPENMCP_INTERNAL_TOKEN` (minimálně 32 znaků) a porovnává proof
token konstantním časem ještě před načtením per-user credentials z Vaultu.
Klientem podvržená subject hlavička bez proof tokenu je odmítnuta.

### `self-hosted`

FastMCP `JWTVerifier` ověřuje podpis, issuer a audience. Identita se bere
výhradně z claimů ověřeného access tokenu přes `get_access_token()`; SDK nikdy
nepoužije klientské `X-OpenMCP-*` hlavičky jako fallback.

Povinné proměnné: `OIDC_ISSUER`, `OIDC_JWKS_URI`, `VAULT_ADDR`; volitelně
`OIDC_AUDIENCE` (default slug konektoru).

## Manifest

`connector.yaml` je striktní schéma (`extra=forbid`). Validuje mimo jiné:

- DNS-safe slug a verze;
- unikátní field keys;
- enum choices a defaulty;
- zákaz secret defaultů v YAML;
- typed credentials/user/operator config;
- host, port, path prefix a HTTP metody egress pravidla;
- kurátorovaný `display` blok.

Neznámé pole nebo překlep zastaví start konektoru. `supports_test` musí přesně
odpovídat tomu, zda `run_connector` dostal `test_connection` callback.

Read-only filtr je fail-closed: pokud je instance read-only, zůstanou pouze
nástroje s explicitním `ToolAnnotations(readOnlyHint=True)`. Neznámá boolean
hodnota je chyba, nikoli vypnutí ochrany.

## Delegovaný OAuth (`auth`)

`connector.yaml` může deklarovat blok `auth`. Výchozí typ je `credentials`
(historické chování — per-user secrets jsou v `credentials[]` a čtou se přímo
z Vaultu). Typ `oauth_delegated` popisuje konektor, který upstream volá
krátkodobým access tokenem vyměněným z per-user refresh tokenu:

```yaml
auth:
  type: oauth_delegated
  provider: dotykacka
  operator_fields:
    - {key: client_id, label: "Client ID", type: string, required: true}
    - {key: client_secret, label: "Client Secret", type: string, secret: true, required: true}
  runtime_secrets: [refresh_token, cloud_id]
```

Validace pro `oauth_delegated`: `credentials[]` musí být prázdné, `provider` je
povinný, `operator_fields` musí obsahovat `client_id` a `client_secret`
(`client_secret` s `secret: true`) a `runtime_secrets` musí být neprázdné.
Konektor musí nastavit `sdk_min_version: 0.3.0`.

`operator_fields` vyplňuje operátor (registrace OAuth aplikace). Platforma
provede user-consent flow a zapíše `runtime_secrets` do per-user Vault blobu
`secret/data/users/{sub}/{slug}`, např. `{"refresh_token": "...", "cloud_id": "..."}`
(namísto `api_key`). SDK je načte do `ctx.secrets` a sestaví klienta:

```python
from openmcp_sdk import current_context

ctx = current_context()
token = ctx.oauth.access_token()   # lazy exchange, in-memory cache ~55 min
cloud = ctx.oauth.cloud_id
# Authorization: Bearer {token}
```

`ctx.oauth` je `DelegatedOAuthClient` (pro typ `credentials` je `None`).
`access_token()` vymění refresh token přes provider a cachuje výsledek do expirace;
`invalidate()` cache zruší (volat při upstream 401). Provideři jsou v
`openmcp_sdk.providers` (built-in `dotykacka`): exchange je
`POST https://api.dotykacka.cz/v2/signin/token` s hlavičkou
`Authorization: User {refresh_token}` a tělem `{"_cloudId": cloud_id}` → `201`
`{"accessToken": "..."}`. Bez explicitního TTL se token cachuje ~55 min.

V `local-stdio` se `runtime_secrets` čtou z proměnných `<SLUG>_<KEY>`
(např. `DOTYKACKA_REFRESH_TOKEN`, `DOTYKACKA_CLOUD_ID`).

## Interní test spojení

`POST /test` se vytvoří jen pro konektor s `test_connection` callbackem. Route:

- vyžaduje `X-OpenMCP-Test-Token` shodný s `OPENMCP_INTERNAL_TOKEN`;
- má limit těla 64 KiB;
- striktně kontroluje rozdělení `secrets`/`config` podle manifestu;
- doplní typed operator config;
- spustí synchronní callback mimo event loop a podporuje také async callback.

Self-hosted konektor bez interního testovacího volajícího callback obvykle
neimplementuje a route vůbec nevystaví.

## Vývoj

```bash
uv run --isolated --python 3.12 --with pytest --with . python -m pytest -q
```

Manifest lze zkontrolovat bez spuštění serveru:

```bash
openmcp-sdk validate connector.yaml
```

## Distribuční adaptéry

SDK umí z jednoho release kontraktu vyrenderovat pravdivé adaptéry pro Claude
Desktop MCPB 0.4, OpenAI remote plugin submission a Gemini CLI Extension.
Lokální a remote režim jsou striktně oddělené. Součástí je fail-closed gate pro
dependency locky, přesný content manifest, Syft SPDX 2.3 SBOM skutečného
payloadu, Trivy scan, keyless Cosign podpis a SLSA provenance. Trivy report
musí obsahovat reálný dependency target a hash content manifestu:

```bash
adapter_staging="$(mktemp -d)"
openmcp-sdk render-adapters connector.yaml distribution.yaml \
  --output "$adapter_staging"
openmcp-sdk verify-release release-gate.yaml \
  --root . --source-commit "$GITHUB_SHA" \
  --output release/release-evidence.json
```

OpenAI výstup je pouze fail-closed operator handoff (`installable: false`,
`submission_state: blocked`), nikoli lokální balíček. Neprovisionovanou review
URL ani neschválenou privacy policy nenahrazuje 404 placeholderem. Gemini
výstup používá remote `httpUrl` a OAuth discovery bez `trust`.
MCPB vzniká jen v `local` režimu, používá hostitelský Node.js runtime,
zamknutý `package-lock.json` a předem sestavený `dist/*` entry point a balí se
upstream `mcpb` CLI.

Přesné schéma, příklady a bezpečnostní invarianty jsou v
[docs/DISTRIBUTION.md](docs/DISTRIBUTION.md).

Pro hosted a self-hosted režim lze nastavit `VAULT_TIMEOUT` (v sekundách,
výchozí 10). Při interním Vault TLS nastavte `VAULT_CACERT` na připojený
PEM CA bundle; SDK ho předá `hvac` pro ověření certifikátu i hostname a
nenabízí přepínač pro vypnutí TLS verifikace. Vault provider má bounded cache,
singleflight, exponenciální
retry pro dočasné chyby a circuit breaker; limity lze nastavit při přímém
vytvoření `VaultProvider`. Pro async aplikace je dostupný
`AsyncVaultProvider`, který nespouští blokující Vault volání v event loopu.
SDK řeší jen společný runtime; API klient, doménové modely a všechny
konektorové závislosti patří do konkrétního konektoru.

SDK vyžaduje FastMCP `>=3.2,<4`. Starší FastMCP 2.x se nesmí použít v novém
release locku; artifact content gate by jej kvůli aktuálním CRITICAL/HIGH
nálezům fail-closed odmítl.

Balík obsahuje `py.typed`; verze má jediný zdroj pravdy v
`openmcp_sdk/_version.py`.
