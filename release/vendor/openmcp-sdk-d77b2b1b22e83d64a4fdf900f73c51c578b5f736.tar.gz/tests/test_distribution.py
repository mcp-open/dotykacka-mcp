from __future__ import annotations

import json
import os
import shutil
import sys
import textwrap
import zipfile
from pathlib import Path

import pytest
import yaml

from openmcp_sdk.distribution import (
    load_distribution,
    pack_mcpb,
    render_distribution,
)


def _manifest(
    tmp_path: Path, *, credentials: bool = False, directory: bool = False
) -> Path:
    data = {
        "slug": "demo",
        "name": "Demo",
        "version": "1.2.3",
        "summary": "Bezpečný demo konektor",
        "display": {
            "schema_version": 1,
            "capabilities": ["Čtení demo dat"],
            "permissions": ["Pouze čtení"],
            "data_handling": "Bez ukládání zákaznických dat.",
            "example_query": "Vyhledej demo záznam.",
            "tools": [
                {"name": "lookup", "description": "Vyhledá záznam"}
            ],
            "locales": {
                locale: {
                    "name": "Demo",
                    "description": "Bezpečný demo konektor",
                    "capabilities": ["Čtení demo dat"],
                    "permissions": ["Pouze čtení"],
                    "data_handling": "Bez ukládání zákaznických dat.",
                    "example_query": "Vyhledej demo záznam.",
                    "tools": [
                        {
                            "name": "lookup",
                            "description": "Vyhledá demo záznam",
                        }
                    ],
                }
                for locale in ("cs", "sk")
            },
        },
    }
    if credentials:
        data["credentials"] = [
            {
                "key": "api_key",
                "label": "API klíč",
                "secret": True,
                "required": True,
                "hint": "Osobní API klíč",
            }
        ]
        for locale in ("cs", "sk"):
            data["display"]["locales"][locale]["fields"] = [
                {"key": "api_key", "label": "API klíč"}
            ]
    if directory:
        data["user_config"] = [
            {
                "key": "allowed_directories",
                "label": "Povolené složky",
                "type": "directory",
                "required": True,
                "multiple": True,
                "hint": "Vyberte složky, které smí konektor číst.",
            }
        ]
        for locale in ("cs", "sk"):
            data["display"]["locales"][locale]["fields"] = [
                {
                    "key": "allowed_directories",
                    "label": "Povolené složky",
                }
            ]
    path = tmp_path / "connector.yaml"
    path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    return path


def _publisher(*, privacy_policy: bool = True) -> dict[str, str]:
    publisher = {
        "name": "OpenMCP",
        "homepage": "https://openmcp.cz",
        "support": "https://openmcp.cz/podpora",
        "documentation": "https://openmcp.cz/dokumentace",
        "repository": "https://github.com/mcp-open/demo-mcp",
    }
    if privacy_policy:
        publisher["privacy_policy"] = "https://openmcp.cz/soukromi"
    return publisher


def _write_config(tmp_path: Path, data: dict) -> Path:
    path = tmp_path / "distribution.yaml"
    path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    return path


def _remote_config() -> dict:
    return {
        "schema_version": 1,
        "mode": "remote",
        "display_name": "OpenMCP Demo",
        "description": "Demo přes vzdálený OpenMCP workspace.",
        "license": "Apache-2.0",
        "publisher": _publisher(privacy_policy=False),
        "remote": {
            "template_mcp_server_url": (
                "https://mcp.openmcp.cz/w/{workspace}/mcp"
            ),
            "oauth_scopes": ["mcp"],
            "adapters": ["openai", "gemini"],
        },
    }


def test_remote_render_is_exact_deterministic_and_never_claims_mcpb(tmp_path):
    manifest = _manifest(tmp_path)
    config = _write_config(tmp_path, _remote_config())

    first = render_distribution(manifest, config, tmp_path / "out-1")
    second = render_distribution(manifest, config, tmp_path / "out-2")

    assert first == second
    assert first["mode"] == "remote"
    assert {item["target"] for item in first["artifacts"]} == {
        "openai_remote",
        "gemini_remote",
    }
    assert first["staging"] == []
    assert not list((tmp_path / "out-1").rglob("*.mcpb"))

    submission = json.loads(
        (tmp_path / "out-1/openai/submission.json").read_text(encoding="utf-8")
    )
    assert submission["schema"] == "openmcp.openai-plugin-submission.v2"
    assert submission["installable"] is False
    assert submission["submission_state"] == "blocked"
    assert submission["mcp_server_url"] is None
    assert submission["workspace_mcp_server_url_template"] == (
        "https://mcp.openmcp.cz/w/{workspace}/mcp"
    )
    assert submission["authentication"] == {
        "type": "oauth2",
        "scopes": ["mcp"],
        "protected_resource_metadata": None,
        "protected_resource_metadata_template": (
            "https://mcp.openmcp.cz/.well-known/"
            "oauth-protected-resource/w/{workspace}/mcp"
        ),
    }
    assert "privacy_policy" not in submission["publisher"]
    assert submission["submission_gates"] == {
        "concrete_mcp_server_url": "missing",
        "privacy_policy_url": "missing",
        "scan_tools": "required",
        "external_demo_credentials": "required",
        "chatgpt_and_codex_surface_e2e": "required",
        "organization_verification": "required",
        "domain_verification": "required",
        "breaking_tool_schema_changes": "forbidden",
    }
    assert "review-fixture" not in json.dumps(submission)
    assert submission["tools"] == [
        {
            "annotations": {
                "destructiveHint": False,
                "openWorldHint": False,
                "readOnlyHint": True,
            },
            "description": "Vyhledá záznam",
            "name": "demo__lookup",
            "securitySchemes": [
                {"scopes": ["mcp"], "type": "oauth2"}
            ],
        }
    ]

    with zipfile.ZipFile(
        tmp_path / "out-1/openmcp-demo-1.2.3-gemini.zip"
    ) as archive:
        assert archive.namelist() == [
            "GEMINI.md",
            "INSTALL.md",
            "gemini-extension.json",
        ]
        extension = json.loads(archive.read("gemini-extension.json"))
    server = extension["mcpServers"]["demo"]
    assert server["httpUrl"] == "${OPENMCP_MCP_URL}"
    assert server["authProviderType"] == "dynamic_discovery"
    assert server["includeTools"] == ["demo__lookup"]
    assert "trust" not in server
    assert extension["settings"][0]["envVar"] == "OPENMCP_MCP_URL"
    assert extension["settings"][0]["sensitive"] is True


def test_openai_handoff_marks_supplied_urls_unverified(tmp_path):
    manifest = _manifest(tmp_path)
    data = _remote_config()
    data["publisher"]["privacy_policy"] = "https://openmcp.cz/soukromi"
    data["remote"]["mcp_server_url"] = (
        "https://mcp.openmcp.cz/w/concrete-review/mcp"
    )
    config = _write_config(tmp_path, data)

    render_distribution(manifest, config, tmp_path / "out")

    submission = json.loads(
        (tmp_path / "out/openai/submission.json").read_text(encoding="utf-8")
    )
    assert submission["mcp_server_url"].endswith("/w/concrete-review/mcp")
    assert submission["authentication"]["protected_resource_metadata"] == (
        "https://mcp.openmcp.cz/.well-known/"
        "oauth-protected-resource/w/concrete-review/mcp"
    )
    assert submission["publisher"]["privacy_policy"] == (
        "https://openmcp.cz/soukromi"
    )
    assert submission["submission_state"] == "blocked"
    assert submission["submission_gates"]["concrete_mcp_server_url"] == (
        "provided_unverified"
    )
    assert submission["submission_gates"]["privacy_policy_url"] == (
        "provided_unverified"
    )


@pytest.mark.parametrize(
    "mutate,expected",
    [
        (
            lambda data: data["remote"].update(
                {"mcp_server_url": "http://mcp.openmcp.cz/w/a/mcp"}
            ),
            "HTTPS",
        ),
        (
            lambda data: data["remote"].update(
                {"mcp_server_url": "https://mcp.openmcp.cz/mcp"}
            ),
            "/w/<workspace>/mcp",
        ),
        (
            lambda data: data["remote"].update(
                {"oauth_scopes": ["mcp", "offline_access"]}
            ),
            "pouze scope mcp",
        ),
        (
            lambda data: data["remote"].update({"adapters": ["gemini"]}),
            "právě adaptéry openai a gemini",
        ),
    ],
)
def test_remote_config_fails_closed(tmp_path, mutate, expected):
    data = _remote_config()
    mutate(data)
    path = _write_config(tmp_path, data)
    with pytest.raises(ValueError, match=expected):
        load_distribution(path)


def test_local_distribution_requires_privacy_policy(tmp_path):
    data = _local_config()
    data["publisher"].pop("privacy_policy")

    with pytest.raises(ValueError, match="privacy_policy"):
        load_distribution(_write_config(tmp_path, data))


def test_remote_render_rejects_namespaced_tool_over_client_limit(tmp_path):
    manifest = _manifest(tmp_path)
    data = yaml.safe_load(manifest.read_text(encoding="utf-8"))
    data["display"]["tools"][0]["name"] = "x" * 60
    for locale in ("cs", "sk"):
        data["display"]["locales"][locale]["tools"][0]["name"] = "x" * 60
    manifest.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")

    with pytest.raises(ValueError, match="nejvýše 63"):
        render_distribution(
            manifest,
            _write_config(tmp_path, _remote_config()),
            tmp_path / "out",
        )


def test_distribution_rejects_write_capable_manifest(tmp_path):
    manifest = _manifest(tmp_path)
    data = yaml.safe_load(manifest.read_text(encoding="utf-8"))
    data["capabilities"] = {
        "default_read_only": False,
        "supports_write": True,
    }
    manifest.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")

    with pytest.raises(ValueError, match="read-only"):
        render_distribution(
            manifest,
            _write_config(tmp_path, _remote_config()),
            tmp_path / "out",
        )


def test_distribution_rejects_legacy_display_schema(tmp_path):
    manifest = _manifest(tmp_path)
    data = yaml.safe_load(manifest.read_text(encoding="utf-8"))
    data["display"].pop("schema_version")
    data["display"].pop("locales")
    manifest.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")

    with pytest.raises(ValueError, match="publikační display"):
        render_distribution(
            manifest,
            _write_config(tmp_path, _remote_config()),
            tmp_path / "out",
        )


def test_distribution_rejects_cross_platform_unsafe_path(tmp_path):
    data = _local_config()
    data["claude_mcpb"]["include"] = [
        "dist",
        "package.json",
        "..\\package-lock.json",
    ]

    with pytest.raises(ValueError, match="přenositelná"):
        load_distribution(_write_config(tmp_path, data))


def test_local_contract_requires_exact_node_command(tmp_path):
    data = _local_config()
    data["claude_mcpb"]["server"]["args"].append("--inspect")

    with pytest.raises(ValueError, match="placeholdery"):
        load_distribution(_write_config(tmp_path, data))


def test_local_node_contract_requires_exact_bundled_entry_point(tmp_path):
    data = _local_config()
    data["claude_mcpb"]["server"]["args"] = ["dist/index.js"]

    with pytest.raises(ValueError, match="první arg"):
        load_distribution(_write_config(tmp_path, data))

    data = _local_config()
    data["claude_mcpb"]["server"]["entry_point"] = "src/index.ts"
    data["claude_mcpb"]["server"]["args"] = ["${__dirname}/src/index.ts"]

    with pytest.raises(ValueError, match=r"dist/\*"):
        load_distribution(_write_config(tmp_path, data))


def test_local_node_contract_requires_exact_npm_lock(tmp_path):
    data = _local_config()
    data["claude_mcpb"]["include"].remove("package-lock.json")

    with pytest.raises(ValueError, match="package-lock.json"):
        load_distribution(_write_config(tmp_path, data))


def test_local_directory_picker_maps_to_exact_process_args(tmp_path):
    manifest = _manifest(tmp_path, directory=True)
    source = tmp_path / "bundle-src"
    (source / "dist").mkdir(parents=True)
    (source / "dist/index.js").write_text(
        "process.stdin.resume();\n", encoding="utf-8"
    )
    (source / "package.json").write_text(
        '{"name":"openmcp-local-files","version":"1.2.3","type":"module"}\n',
        encoding="utf-8",
    )
    (source / "package-lock.json").write_text(
        '{"name":"openmcp-local-files","version":"1.2.3","lockfileVersion":3,'
        '"packages":{}}\n',
        encoding="utf-8",
    )
    data = _local_config()
    data["claude_mcpb"]["server"]["args"].append(
        "${user_config.allowed_directories}"
    )

    render_distribution(
        manifest,
        _write_config(tmp_path, data),
        tmp_path / "out",
    )
    rendered = json.loads(
        (tmp_path / "out/claude-mcpb/manifest.json").read_text(encoding="utf-8")
    )

    assert rendered["user_config"]["allowed_directories"] == {
        "type": "directory",
        "title": "Povolené složky",
        "description": "Vyberte složky, které smí konektor číst.",
        "required": True,
        "multiple": True,
    }
    assert rendered["server"]["mcp_config"]["args"] == [
        "${__dirname}/dist/index.js",
        "${user_config.allowed_directories}",
    ]
    assert "DEMO_ALLOWED_DIRECTORIES" not in rendered["server"]["mcp_config"]["env"]


def test_local_directory_picker_rejects_missing_or_unknown_arg(tmp_path):
    manifest = _manifest(tmp_path, directory=True)
    config = _write_config(tmp_path, _local_config())

    with pytest.raises(ValueError, match="directory/file"):
        render_distribution(manifest, config, tmp_path / "out")

    data = _local_config()
    data["claude_mcpb"]["server"]["args"].append("${user_config.unknown_root}")
    with pytest.raises(ValueError, match="directory/file"):
        render_distribution(
            _manifest(tmp_path),
            _write_config(tmp_path, data),
            tmp_path / "other-out",
        )


@pytest.mark.parametrize("version", ["01.2.3", "1.2.3-01"])
def test_distribution_rejects_invalid_semver(tmp_path, version):
    manifest = _manifest(tmp_path)
    data = yaml.safe_load(manifest.read_text(encoding="utf-8"))
    data["version"] = version
    manifest.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")

    with pytest.raises(ValueError, match="SemVer"):
        render_distribution(
            manifest,
            _write_config(tmp_path, _remote_config()),
            tmp_path / "out",
        )


def _local_config() -> dict:
    return {
        "schema_version": 1,
        "mode": "local",
        "display_name": "OpenMCP Local Files",
        "description": "Lokální read-only souborový konektor.",
        "license": "Apache-2.0",
        "publisher": _publisher(),
        "claude_mcpb": {
            "source_root": "bundle-src",
            "include": ["dist", "package.json", "package-lock.json"],
            "server": {
                "type": "node",
                "entry_point": "dist/index.js",
                "command": "node",
                "args": ["${__dirname}/dist/index.js"],
            },
            "platforms": ["darwin", "win32"],
            "runtime_version": ">=20.0.0",
        },
    }


def test_local_render_maps_secret_to_mcpb_user_config(tmp_path):
    manifest = _manifest(tmp_path, credentials=True)
    source = tmp_path / "bundle-src"
    (source / "dist").mkdir(parents=True)
    (source / "dist/index.js").write_text(
        "process.stdin.resume();\n", encoding="utf-8"
    )
    (source / "package.json").write_text(
        '{"name":"openmcp-local-files","version":"1.2.3","type":"module"}\n',
        encoding="utf-8",
    )
    (source / "package-lock.json").write_text(
        '{"name":"openmcp-local-files","version":"1.2.3","lockfileVersion":3,'
        '"packages":{}}\n',
        encoding="utf-8",
    )
    config = _write_config(tmp_path, _local_config())

    result = render_distribution(manifest, config, tmp_path / "out")

    assert result["mode"] == "local"
    assert result["artifacts"] == []
    assert result["staging"] == ["claude-mcpb"]
    rendered = json.loads(
        (tmp_path / "out/claude-mcpb/manifest.json").read_text(encoding="utf-8")
    )
    assert rendered["manifest_version"] == "0.4"
    assert rendered["compatibility"] == {
        "platforms": ["darwin", "win32"],
        "runtimes": {"node": ">=20.0.0"},
    }
    assert rendered["user_config"]["api_key"]["sensitive"] is True
    assert (
        rendered["server"]["mcp_config"]["env"]["DEMO_API_KEY"]
        == "${user_config.api_key}"
    )
    assert rendered["server"]["mcp_config"]["env"]["OPENMCP_MODE"] == "local-stdio"
    assert not (tmp_path / "out/claude-mcpb/connector.yaml").exists()


def test_local_node_render_uses_host_node_runtime(tmp_path):
    manifest = _manifest(tmp_path)
    source = tmp_path / "bundle-src"
    (source / "dist").mkdir(parents=True)
    (source / "dist/index.js").write_text(
        "process.stdin.resume();\n", encoding="utf-8"
    )
    (source / "package.json").write_text(
        '{"name":"openmcp-local-files","version":"1.2.3","type":"module"}\n',
        encoding="utf-8",
    )
    (source / "package-lock.json").write_text(
        '{"name":"openmcp-local-files","version":"1.2.3","lockfileVersion":3,'
        '"packages":{}}\n',
        encoding="utf-8",
    )
    config = _write_config(tmp_path, _local_config())

    result = render_distribution(manifest, config, tmp_path / "out")

    assert result["mode"] == "local"
    rendered = json.loads(
        (tmp_path / "out/claude-mcpb/manifest.json").read_text(encoding="utf-8")
    )
    assert rendered["server"] == {
        "type": "node",
        "entry_point": "dist/index.js",
        "mcp_config": {
            "command": "node",
            "args": ["${__dirname}/dist/index.js"],
            "env": {"OPENMCP_MODE": "local-stdio"},
        },
    }
    assert rendered["compatibility"]["runtimes"] == {"node": ">=20.0.0"}


def test_local_render_includes_explicit_manifest_icon(tmp_path):
    manifest = _manifest(tmp_path)
    source = tmp_path / "bundle-src"
    (source / "dist").mkdir(parents=True)
    (source / "assets").mkdir()
    (source / "dist/index.js").write_text(
        "process.stdin.resume();\n", encoding="utf-8"
    )
    (source / "assets/icon.svg").write_text(
        '<svg xmlns="http://www.w3.org/2000/svg"></svg>\n',
        encoding="utf-8",
    )
    (source / "package.json").write_text("{}\n", encoding="utf-8")
    (source / "package-lock.json").write_text(
        '{"lockfileVersion":3,"packages":{}}\n', encoding="utf-8"
    )
    data = _local_config()
    data["claude_mcpb"]["icon"] = "assets/icon.svg"
    data["claude_mcpb"]["include"].append("assets/icon.svg")

    render_distribution(
        manifest,
        _write_config(tmp_path, data),
        tmp_path / "out",
    )

    rendered = json.loads(
        (tmp_path / "out/claude-mcpb/manifest.json").read_text(encoding="utf-8")
    )
    assert rendered["icon"] == "assets/icon.svg"
    assert (tmp_path / "out/claude-mcpb/assets/icon.svg").is_file()


def test_local_render_rejects_icon_missing_from_include(tmp_path):
    data = _local_config()
    data["claude_mcpb"]["icon"] = "assets/icon.svg"

    with pytest.raises(ValueError, match="icon.*include"):
        load_distribution(_write_config(tmp_path, data))


def test_local_render_rejects_symlink_and_secret_like_source(tmp_path):
    manifest = _manifest(tmp_path)
    source = tmp_path / "bundle-src"
    (source / "dist").mkdir(parents=True)
    secret = tmp_path / "private-key.pem"
    secret.write_text("secret", encoding="utf-8")
    os.symlink(secret, source / "dist/index.js")
    (source / "package.json").write_text("{}\n", encoding="utf-8")
    (source / "package-lock.json").write_text(
        '{"lockfileVersion":3,"packages":{}}\n', encoding="utf-8"
    )
    config = _write_config(tmp_path, _local_config())

    with pytest.raises(ValueError, match="symlink"):
        render_distribution(manifest, config, tmp_path / "out")


def test_local_render_requires_included_entry_point(tmp_path):
    manifest = _manifest(tmp_path)
    source = tmp_path / "bundle-src"
    (source / "dist").mkdir(parents=True)
    (source / "dist/other.js").write_text(
        "process.stdin.resume();\n", encoding="utf-8"
    )
    (source / "package.json").write_text("{}\n", encoding="utf-8")
    (source / "package-lock.json").write_text(
        '{"lockfileVersion":3,"packages":{}}\n', encoding="utf-8"
    )
    config = _write_config(tmp_path, _local_config())

    with pytest.raises(ValueError, match="entry_point"):
        render_distribution(manifest, config, tmp_path / "out")


def test_local_render_rejects_intermediate_source_root_symlink(tmp_path):
    manifest = _manifest(tmp_path)
    outside = tmp_path / "outside"
    (outside / "bundle-src/dist").mkdir(parents=True)
    (outside / "bundle-src/dist/index.js").write_text(
        "process.stdin.resume();\n", encoding="utf-8"
    )
    (outside / "bundle-src/package.json").write_text(
        "{}\n", encoding="utf-8"
    )
    (outside / "bundle-src/package-lock.json").write_text(
        '{"lockfileVersion":3,"packages":{}}\n', encoding="utf-8"
    )
    alias = tmp_path / "alias"
    alias.symlink_to(outside, target_is_directory=True)
    data = _local_config()
    data["claude_mcpb"]["source_root"] = "alias/bundle-src"
    config = _write_config(tmp_path, data)

    with pytest.raises(ValueError, match="symlink"):
        render_distribution(manifest, config, tmp_path / "out")


def test_render_refuses_nonempty_output(tmp_path):
    output = tmp_path / "out"
    output.mkdir()
    (output / "stale").write_text("old", encoding="utf-8")
    with pytest.raises(ValueError, match="není prázdný"):
        render_distribution(
            _manifest(tmp_path),
            _write_config(tmp_path, _remote_config()),
            output,
        )


def test_pack_mcpb_requires_external_validation_and_outputs_digest(tmp_path):
    staging = tmp_path / "staging"
    staging.mkdir()
    (staging / "manifest.json").write_text("{}", encoding="utf-8")
    fake = tmp_path / "mcpb"
    fake.write_text(
        textwrap.dedent(
            f"""\
            #!{sys.executable}
            import pathlib
            import sys
            import zipfile
            if sys.argv[1] == "validate":
                raise SystemExit(0)
            if sys.argv[1] == "pack":
                source = pathlib.Path(sys.argv[2])
                with zipfile.ZipFile(sys.argv[3], "w") as archive:
                    archive.write(source / "manifest.json", "manifest.json")
                raise SystemExit(0)
            raise SystemExit(7)
            """
        ),
        encoding="utf-8",
    )
    fake.chmod(0o755)

    result = pack_mcpb(
        staging, tmp_path / "demo.mcpb", mcpb_binary=str(fake)
    )

    assert result["target"] == "claude_mcpb"
    second = pack_mcpb(
        staging, tmp_path / "demo-second.mcpb", mcpb_binary=str(fake)
    )
    assert result["sha256"] == second["sha256"]


def test_pack_mcpb_rejects_symlink_in_arbitrary_staging(tmp_path):
    staging = tmp_path / "staging"
    staging.mkdir()
    (staging / "manifest.json").write_text("{}", encoding="utf-8")
    outside = tmp_path / "outside.txt"
    outside.write_text("secret", encoding="utf-8")
    (staging / "linked.txt").symlink_to(outside)

    with pytest.raises(ValueError, match="symlink"):
        pack_mcpb(staging, tmp_path / "demo.mcpb", mcpb_binary="/bin/true")


@pytest.mark.skipif(
    not os.environ.get("OPENMCP_MCPB_BIN"),
    reason="pinned upstream mcpb CLI is not installed",
)
def test_local_render_packs_with_real_upstream_mcpb_cli(tmp_path):
    manifest = _manifest(tmp_path, credentials=True)
    source = tmp_path / "bundle-src"
    (source / "dist").mkdir(parents=True)
    (source / "dist/index.js").write_text(
        "process.stdin.resume();\n", encoding="utf-8"
    )
    (source / "package.json").write_text(
        '{"name":"openmcp-local-files","version":"1.2.3","type":"module"}\n',
        encoding="utf-8",
    )
    (source / "package-lock.json").write_text(
        '{"name":"openmcp-local-files","version":"1.2.3","lockfileVersion":3,'
        '"packages":{}}\n',
        encoding="utf-8",
    )
    config = _write_config(tmp_path, _local_config())
    render_distribution(manifest, config, tmp_path / "out")
    binary = shutil.which(os.environ["OPENMCP_MCPB_BIN"])
    assert binary is not None

    result = pack_mcpb(
        tmp_path / "out/claude-mcpb",
        tmp_path / "openmcp-local-files-1.2.3.mcpb",
        mcpb_binary=binary,
    )

    assert result["target"] == "claude_mcpb"
    with zipfile.ZipFile(tmp_path / "openmcp-local-files-1.2.3.mcpb") as archive:
        manifest_json = json.loads(archive.read("manifest.json"))
    assert manifest_json["manifest_version"] == "0.4"
    assert manifest_json["server"]["type"] == "node"
    assert manifest_json["compatibility"]["platforms"] == ["darwin", "win32"]
    assert manifest_json["compatibility"]["runtimes"] == {"node": ">=20.0.0"}

    second = pack_mcpb(
        tmp_path / "out/claude-mcpb",
        tmp_path / "openmcp-local-files-1.2.3-second.mcpb",
        mcpb_binary=binary,
    )
    assert result["sha256"] == second["sha256"]
