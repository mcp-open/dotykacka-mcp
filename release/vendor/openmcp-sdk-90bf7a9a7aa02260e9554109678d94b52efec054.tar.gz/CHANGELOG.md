# Changelog

## 0.4.2 — nevydané

### Přidáno

- **Distribuční core a release gate** — `distribution.yaml` striktně odděluje
  local Claude MCPB 0.4 od remote OpenAI/Gemini adaptérů.
  Lokální kontrakt používá hostitelský Node.js runtime, zamknutý
  `package-lock.json`, předem sestavený `dist/*` entry point a přesnou
  `${__dirname}` command šablonu podle schváleného Local Files pilotu.
  `directory`/`file` user config se renderuje jako nativní MCPB picker a do
  procesu se předává pouze přes přesný `${user_config.*}` argument, ne přes
  environment nebo volný command fragment.
  `render-adapters`, `pack-mcpb`, `build-contents-manifest`,
  `bind-trivy-report`, `build-provenance`, `verify-release` a
  `withdraw-release` vytvářejí deterministické artefakty a fail-closed ověřují
  locky, přesný obsah archivu, Syft SPDX 2.3 a Trivy
  vulnerability/secret/misconfiguration scan skutečného payloadu,
  keyless Cosign a SLSA provenance. Remote režim nikdy nevydá MCPB; OpenAI
  handoff je explicitně neinstalovatelný; Gemini nepřebírá `trust`. Symlinky,
  stale output, CRITICAL/secret nálezy a neplatná HIGH schválení release
  zablokují. Withdrawal je samostatný podepsatelný statement navázaný na hash
  přesného release evidence.
- Local MCPB renderer váže explicitně zahrnutý icon asset přímo do
  `manifest.json`; nepřipustí manifestový odkaz na soubor mimo `include`.

### Změněno

- OpenAI operator handoff používá schéma v2 a fail-closed rozlišuje chybějící
  od pouze dodaných, ale neověřených submission vstupů. Neprovisionovanou MCP
  URL ani neschválenou privacy policy už renderer nenahrazuje placeholderem;
  lokální MCPB nadále vyžaduje schválenou privacy URL. Všechny podporované
  remote nástroje jsou read-only a proto mají pravdivé `openWorldHint: false`.
- Minimální FastMCP baseline je `3.2`; runtime i conformance enumerace používají
  FastMCP 3 `list_tools()` a ponechávají kompatibilní fallback pro starší
  vložené instance. Důvodem je fail-closed odstranění aktuálních CRITICAL/HIGH
  nálezů, které content scan odhalil ve FastMCP 2.x dependency stromu.
- Testovací baseline používá Pytest `9.0.3`; starší `8.4.2` zůstával v aktuální
  vulnerability databázi s opraveným MEDIUM nálezem.

## 0.4.0 — nevydané

Sjednocení konektorů: to, co si dnes píše každý konektor sám, se stahuje do SDK.

### Přidáno

- **`runtime:` blok v manifestu** (`Manifest.runtime`) — `replicas`, `pii_salt`,
  `health_path`, `vault_ttl`. Zrcadlí Go `provision.Runtime`
  (`api/internal/provision/spec.go`) včetně sémantiky „nezadáno": defaulty se
  v SDK ZÁMĚRNĚ nedoplňují, patří rendereru.
  **Oprava:** `dotykacka-mcp` měla tento blok v manifestu, ale `Manifest` ho
  neznal a `extra="forbid"` shodil start konektoru. Konektor se tedy vůbec
  nedal spustit; jeho `tests/test_manifest.py` to nezachytil, protože záměrně
  obcházel `load_manifest`.
- `SERVED_HEALTH_PATHS` — jediný zdroj pravdy sdílený mezi validátorem
  manifestu a HTTP transportem. `runtime.health_path`, kterou SDK neservíruje,
  je odteď chyba manifestu, ne pod, který se nikdy nedostane do ready.
- **`openmcp_sdk.http`** — sdílený `UpstreamClient` nahrazující tři téměř
  identické `client.py`. `RetryPolicy` s `Retry-After`, injektovatelný
  `transport` i `sleep` (testy přes `httpx.MockTransport`, bez reálného
  čekání), `token_provider` s jednorázovou obnovou při 401, `encode_segment()`
  a `get_dict()`. **Zápisy se neopakují by default** pro všechny non-GET metody —
  z komentáře v jednom konektoru se stává pravidlo SDK.
- `ConnectorError.status` — HTTP stav upstreamu pro strukturovanou klasifikaci
  (`test_connection`), záměrně mimo serializovanou zprávu.
- **`openmcp_sdk.pii`** — pseudonymizace, která dnes žije ve třech kopiích
  (828 řádků, jádro bit-identické). Konektoru zůstávají jen tabulky polí.
  `PiiPolicy` je deklarativní (kategorie, jména, volný text, substring fallback,
  podmíněná jména, person-scope), `Pseudonymizer` má hook `handle_field()`
  pro doménové výjimky.
  - `derive_key(*scope)` — `derive_key(sub)` dá **bit-identické** bajty jako
    doposud raynet/upgates, `derive_key(sub, cloud_id)` odpovídá dotykačkovu
    `sub:cloud_id`. Vícedílný rozsah je doporučený všude, kde existuje
    skutečný datový tenant: jeden uživatel může propojit jiný tenant a tokeny
    pak nesmí být korelovatelné s předchozím.
  - Bit-identita je zajištěna testem proti zlatým hodnotám spočítaným **původním
    kódem konektorů**, ne tímto modulem. Token je externě viditelný,
    dlouhodobě stabilní kontrakt.
  - Pořadí vyhodnocení je kanonizováno na `kategória → freetext → substring`.
    Raynet to tak už dělal, upgates měl opačné pořadí — ale **ověřeno, že
    žádný ze tří konektorů nemá pole v obou množinách**, takže sjednocení
    nikomu nemění výstup. `PiiPolicy.validate()` takový překryv odmítne
  - `Pseudonymizer.sanitize(data, *, person_scope=False)` — nový nepovinný
    parametr (objeven při migraci dotykačky na tento modul, fáze 2). Bez něj
    `person_scope_fields` zachytí jen vnořený person-scope záznam pod klíčem
    (`{"customer": {...}}`); endpointy, kde je celá odpověď rovnou seznam osob
    (`list_customers`/`list_employees`), potřebují scope vynutit už na vrcholu
    stromu. Zpětně kompatibilní (default `False` = dřívější chování)
    (raynetův `othercontact` je dnes ve `freetext_fields` mrtvý zápis).

- **`openmcp_sdk.write`** — zápisová vrstva zobecněná z raynetu (jediný
  write konektor): `build_payload()` s allowlistem a token guardem,
  `WriteBudget`, `diff_lines()`, `confirm_write()` a orchestrační
  `execute_write()`, která drží pořadí vrstev
  (politika → rozpočet → diff → potvrzení → audit). `audit_write()` loguje
  **názvy polí, nikdy hodnoty**.
  - Souhlas s elicitation se detekuje **na typu**, ne přes
    `type(result).__name__` jako dosud v raynetu. Typy se importují při
    importu modulu, takže rozchod s fastmcp spadne při buildu, ne až při
    prvním zápisu.
  - Dekorátor záměrně není: neviděl by allowlistovaný payload bez
    introspekce podpisu a implicitní magie na bezpečnostní hranici je špatný
    obchod.

- **`openmcp_sdk.tools.tool()`** — registrace nástroje s **povinným** keyword
  argumentem `read_only`. Vrací původní funkci, ne `FunctionTool`, takže se dá
  v unit testu zavolat přímo — přesně ten důvod, pro který template volí plain
  funkci, jen vyřešený jednou v SDK. Chybějící anotace dnes znamená, že nástroj
  v read-only režimu **tiše zmizí**; teď se to nedá zapomenout.
- **`openmcp_sdk.testing` je balíček** s pytest pluginem (entry point `pytest11`),
  takže konektor dostane sdílené fixtures jen tím, že má SDK nainstalované —
  bez vlastního `conftest.py` (dnes mají tři konektory identický).
  - `with_context()` umí nově `policy`, `oauth`, `request_id`
    a `invalidate_credentials`; bez prvních dvou se nedal otestovat ani write
    gating, ani delegovaný OAuth. Poziční argumenty zůstávají kompatibilní.
  - `FakeOAuth`, `FakeElicitation` a `elicitation()` — bez nich se
    `confirm_write` prakticky nedá otestovat, a je to jediná vrstva, která
    prompt injection reálně zastaví.
  - **`ConnectorConformance`** — sada testů, kterou si konektor pustí proti
    svému manifestu: slug proti Go validátoru, egress, `display.tools`
    ↔ registrované nástroje, explicitní `readOnlyHint` u každého,
    `supports_write` ↔ mutující nástroje, `supports_test` ↔ wiring, verze
    manifest ↔ pyproject, `runtime.pii_salt` ↔ existence politiky a
    read-only filtr v subprocesu. Ověřeno proti ares (12 prošlo) i raynetu
    (25 nástrojů v read-only vs 32 ve write režimu).

- **`run_connector` dělá automaticky to, co si dosud musel každý konektor
  pamatovat:**
  - `logging.setup()` jako první krok (vypnutelné `OPENMCP_LOG_SETUP=false`).
    Dosud to volal jediný konektor, a to na úrovni importu `server.py` —
    ostatní čtyři běžely bez redakce tajemství v logech.
  - Nový parametr `pii=`. Invariant `runtime.pii_salt ⟺ pii is not None`
    plus `require_salt()` při startu; identický blok tak zmizí ze tří
    `__main__.py`.
  - Kontrola manifest ↔ zaregistrované nástroje: `display.tools`, explicitní
    `readOnlyHint` u každého a `supports_write` ↔ mutující nástroje.
    **Gatované přes `sdk_min_version`** — pod 0.4.0 jen varování, od 0.4.0
    chyba. Konektory se tak dají překlápět po jednom.
  - Návratová hodnota je `RunResult` (NamedTuple), takže dosavadní
    rozbalení na 3-tuple funguje dál.
- **`openmcp-sdk validate` ověřuje i invarianty platformy** (Go
  `provision.ParseSpec`): slug proti Go regexu, povinný `egress.host`+`port`,
  neprázdné `display.tools` a **shodu adresáře v `Dockerfile` se slugem**.
  „Validate prošlo" tak konečně znamená „platforma to přijme"; předtím mohlo
  říct OK na manifest, který API vzápětí odmítlo. `--sdk-only` kontroly
  platformy přeskočí.
  Ověřeno: ares, raynet, dotykacka i upgates projdou; `template-mcp` padá
  přesně na chybějícím `egress` a `display.tools`.

### Opraveno (nálezy z adversariální revize 0.4)

Revize běžela proti kódu těsně před vydáním; následující chyby vznikly až
v 0.4 a byly ověřeny spuštěním, ne čtením.

- **`encode_segment` neblokoval dot-segmenty.** `..` je v RFC 3986 „unreserved",
  takže ho `quote()` nechal tak — a httpx ho při stavbě URL normalizuje, takže
  `/company/../detail` skončilo jako `/detail`. Funkce, jejímž jediným účelem je
  zabránit vyskočení z cesty, to tedy nedělala. Odteď se dot-segmenty
  odmítají; zároveň se odmítne `None`, list a dict místo tichého
  `str(value)`.
- **`get_json` obcházel `_json()`** — při 200 s HTML tělem (chybová stránka
  z proxy) vyletěla netypovaná `JSONDecodeError`, jejíž text jde modelu.
- **Výjimky z `token_provider`** (`access_token()`, `invalidate()`) unikaly
  nezmapované. `str(exc)` z OAuth klienta — typicky s názvem tenanta — se přes
  fastmcp dostal rovnou do kontextu modelu.
- **`base_url` přijímal nebezpečné tvary:** okolní whitespace (`urlsplit` ho
  ořeže, httpx ne → všechny requesty mířily na relativní adresu), query
  a userinfo (httpx z něj auth neudělá, jen ho nechá v každé URL včetně
  logů).
- **`WriteBudget`: odmítnuté potvrzení čerpalo rozpočet.** Injekce, které
  člověk desetkrát řekne ne, zablokovala uživateli legitimní zápisy na
  celé okno. `check()` (dotaz) a `record()` (započtení) jsou teď oddělené
  a `execute_write` započítává až po potvrzení.
- **`DEFAULT_BUDGET` prosakoval mezi testy** — modulová instance se přes
  celou sadu naplnila přesně na limit, takže další test s výchozím rozpočtem by
  spadl na `FORBIDDEN` v místě, které s příčinou nesouvisí. Přibyl
  `reset()` a autouse fixture v pytest pluginu.
- **`confirm_write` házel `ImportError`** namísto typové hlášky, když fastmcp
  chybí; import je teď uvnitř `try`.
- **Audit v chybové větvi mohl zamaskovat původní výjimku** (`current_context()`
  sám hází, když kontext chybí).
- **`sanitize()` propouštěl osobní údaje** v `tuple`, `set`, `frozenset`,
  `bytes`/`bytearray` a v **klíčích** map — `_walk` znal jen `Mapping`, `list`
  a `str`. Modul se přitom hlásí k fail-closed. Totéž v `contains_token`,
  který nekontroloval klíče, takže zápis s tokenem v klíči prošel přes
  `assert_no_tokens`.
- **Dvojitá tokenizace:** codebook objekt `{id, value}` se nejprve zescruboval
  a poté se tokenizoval už vzniklý token, takže stejný e-mail dal jiný
  token podle tvaru odpovědi. Tím padala hlavní premisa modulu — stabilní,
  korelovatelný token. Tokenizuje se původní hodnota.
- **`sensitive_object_fields` neprocházely sourozence** — `note` nebo `tel`
  vedle `value` prošly otevřeně.
- **Jméno ze samých mezer otrávilo registr známých jmen** a měnilo každý
  prázdný řetězec na konstantní falešný `<NAME_…>` token.
- **`scope_by_sub_and_tenant` tiše přijal `cloud_id=None`** jako literál
  `"None"` — všichni uživatelé bez cloudu sdíleli jeden pseudo-tenant, tedy
  přesný opak toho, k čemu rozsah existuje.
- **Pořadí `freetext` vs. substring fallback** se rozcházelo s dokumentací:
  `description_invoice` se celý tokenizoval do jednoho tokenu místo scrubu.
  `PiiPolicy.validate()` takový přesah odteď odmítne.
- **`run_connector`: invariant `runtime.pii_salt ⟺ pii` je gatovaný** stejně
  jako ostatní startovací kontroly. Bez toho bump SDK **shodil start
  `dotykacka-mcp`**, jejíž `__main__.py` parametr `pii=` ještě nezná — a jejích
  31 testů to nezachytilo, protože `run_connector` nevolají. Gating se navíc
  porovnává přes `base_version`, aby `0.4.0rc1` nepropadl do varování.
- **`OPENMCP_LOG_SETUP=""`** shodilo start; prázdná proměnná je v k8s běžný
  způsob, jak něco „nenastavit", a bere se teď jako nenastavené.
- **Kontrola Dockerfile ↔ slug** přehlížela `COPY --chown=… src ./src`
  a `COPY ./src ./src` a naopak hlásila falešný poplach na `COPY src/ ./src/`.
- `tool` a `RunResult` se dali importovat jen plnou cestou.

### Opraveno (bezpečnost)

- **`AccessPolicy.approval_required` se chovalo jako `read_only`.** `can_call()`
  mělo `mode != "allow_write"`, takže režim „zápis s potvrzením" zápis rovnou
  zamítl, a pole `require_approval` nečetl **nikdo** — přestože ho gateway
  posílá a transport parsuje. Workspace, který si vyžádal zápis s potvrzením,
  tiše dostal žádný zápis. Nové `AccessPolicy.write_decision()` vrací
  `ALLOW | REQUIRE_APPROVAL | DENY`; `require_approval=True` je **override,
  který přebije konektorové `require_write_confirmation=false`** (opačně to
  nejde). `require_write_access()` zůstává záměrně přísné a propouští jen
  `ALLOW` — kdo volá jen ji, nemá jak potvrzení vyžádat.
- **Tělo upstream odpovědi se už nedostane do chybové zprávy.** Raynet i
  upgates do ní lepily `resp.text[:500]`; text, který mohl napsat cizí
  uživatel, tak putoval rovnou do kontextu modelu. Tělo jde do logu (přes
  `logging.redact`), ven jde typová hláška.

### Změněno (BREAKING)

- **`slug` se validuje přísnějším Go regexem** `^[a-z][a-z0-9-]{1,30}[a-z0-9]$`
  (3–32 znaků, začíná písmenem) místo volnějšího DNS-label regexu. Dosud
  mohlo `openmcp-sdk validate` říct OK na slug, který API vzápětí odmítlo.
  Žádný existující konektor se nemění.
- `capabilities.supports_write: false` se vynucuje místo `pass`: rozpor
  s `default_read_only: false` a mrtvý `operator_config.require_write_confirmation`
  jsou odteď chyba manifestu. `egress.methods` se **záměrně neomezují** —
  read-only konektor legitimně používá POST na vyhledávání (ares).

### Zastaralé

- `openmcp_sdk.http_errors` — re-export z `openmcp_sdk.http`, vyvolává
  `DeprecationWarning`. Odstranění v 0.5. Modul existoval od 0.2, ale
  **nepoužíval ho ani jeden konektor** — každý si napsal vlastní chybovou
  hierarchii, protože SDK nenabízelo klienta, který by mapování dělal za něj.

## 0.3.0 — 2026-07-21

- nový `auth` blok v `connector.yaml` s typem `credentials` (default) nebo
  `oauth_delegated`;
- delegovaný OAuth: operátorská `operator_fields` (client_id/client_secret),
  per-user `runtime_secrets` (refresh_token, cloud_id) čtené z Vaultu;
- provider registry (`openmcp_sdk.providers`) s built-in `dotykacka` token
  exchangem;
- `DelegatedOAuthClient` s in-memory cache access tokenu, thread-safe,
  vystavený jako `current_context().oauth` (None pro typ `credentials`);
- konektory s `oauth_delegated` musí nastavit `sdk_min_version: 0.3.0`.

## 0.2.0 — 2026-07-20

- self-hosted identita pouze z ověřených JWT claimů a správné pořadí middleware;
- hosted gateway proof přes `OPENMCP_INTERNAL_TOKEN`;
- autentizovaný, omezený a manifestem validovaný `/test` endpoint;
- fail-closed read-only filtr a striktní boolean parsing;
- striktní typed manifest včetně egress/display;
- bounded singleflight Vault cache a immutable request data;
- invalidace credentials na skutečném upstream 401;
- bezpečnější error mapping, redakce logů a korektní context cleanup;
- jednotná dynamická verze balíku a `py.typed` marker.

## 0.1.0

- první minimální SDK kontrakt pro ARES a template konektor.
